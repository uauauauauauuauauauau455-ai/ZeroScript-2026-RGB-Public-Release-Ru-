# ZeroScript Free — Public AI Adapter (v1.9.2)

Publicly shareable browser extension and local bridge for connecting supported AI chat sites to Roblox Studio through MCP. This package removes creator donation controls, personal Game Pass IDs, and the Discord invite from the interface. The project repository link is retained as the source/release location.

**Note:** selecting an AI site opens that site. It does not guarantee that the site's chat automation is compatible; optional browser permissions and a suitable adapter are required.

## ZeroScript Free 1.9.2 — public release
Use the 🎨 button on the ZeroScript bar to jump directly to “Цвета и темы”. Customize background, border, button accent, text and glow; choose among 19 ready-made themes plus custom colors, browse the 1024-shade palette, enable animation/rainbow border, preview, save, or reset. Preferences persist locally in the browser extension.

Open “Ручной активатор Roblox” for the 3-stage wizard: (1) send the full activation prompt, (2) use the actual list_commands result and request the connected Studio list, (3) check Studio state and confirm readiness only from real tool results. Each step is copied and sent manually; stage navigation itself does not prove that a connection works. The 🎨 Цвета button is visible on the in-chat ZeroScript bar and opens the color/theme section.

<!-- Version note: v1.8.6 adds Google AI Mode (test) to the shared AI directory. -->
# ZeroScript Free - AI Roblox Studio Agent (DeepSeek, Gemini, Kimi, GLM, Qwen, Arena, ChatGPT, TokenWave + 12 more)

Control Roblox Studio with AI, for free. ZeroScript turns a normal AI chat (DeepSeek, Google Gemini, Kimi, GLM, Qwen, or Arena) into an agent that builds and scripts your Roblox game for you: just describe what you want, and it reads/edits scripts, runs Luau, inspects the game tree, and generates assets directly in Roblox Studio. No API key, no terminal, no coding required.

It's a Chrome/Edge browser extension plus a small local bridge that connects the chat to Roblox Studio through the official MCP server. Gemini, Kimi, GLM, Qwen and Arena also work but can be less stable: Gemini tends to stop using the Roblox tools in long sessions, and Kimi sometimes reaches for its own native tools instead of the Roblox commands. On Arena, keep the mode dropdown on **Direct** (ZeroScript only supports Direct mode).

## Setup

**Load the extension manually (Edge or Chrome):**
1. Go to `edge://extensions` (Edge) or `chrome://extensions` (Chrome)
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `zeroscript-extension` folder
5. The extension is now active

**Then set up the Bridge:**
1. **Download the Bridge** from the [GitHub releases page](https://github.com/sebattfg/ZeroScript-Free)
2. **Open Roblox Studio** and load a Place
3. **Enable the MCP server in Roblox Studio** (first time only): click **Assistant AI** in the top bar, then **...** > **Manage MCP Servers** > **Enable Studio as MCP Server**
4. **Run start.bat** - a small window opens, the Bridge is running
5. **Go to https://chat.deepseek.com** (recommended), https://gemini.google.com, https://www.kimi.com, https://chat.z.ai, https://chat.qwen.ai, or https://arena.ai, open a new chat (only works on these exact addresses; on Arena use Direct mode)
6. Click **Start session** in the ZeroScript panel
7. Type what you want to build

📺 [Watch the setup tutorial](https://youtu.be/kPKiZLZ9_Ps)

## Supported sites

| Provider file | Sites |
|---|---|
| `deepseek.js`, `gemini.js`, `kimi.js`, `glm.js`, `qwen.js`, `arena.js` | DeepSeek, Gemini, Kimi, GLM, Qwen, Arena (tested by the original author) |
| `chatgpt.js` | chatgpt.com |
| `tokenwave.js` | tokenwave.ru/chat (sign in / add your API key on the site first) |
| `generic.js` | Claude (claude.ai), Grok, Mistral, Perplexity, Copilot, HuggingChat, Poe, DeepAI, ChatAI, ChatbotChatApp, Alice (alice.yandex.ru), QuillBot |

**Not live-tested:** ChatGPT, TokenWave and everything handled by `generic.js` were written without browser access, so their selectors are best effort. `generic.js` has a built-in fallback that locates the chat list from the text ZeroScript sent, which helps when a site's markup differs from the profile. If a site misbehaves, edit only its entry in `PROFILES` at the top of `providers/generic.js`.

## Architecture (for contributors)

The extension is split between a provider-agnostic core and per-AI-site providers:

```
core/config.js        system prompt, feedback strings, tool categories (global ZS)
core/parser.js        ZeroScript command parsing - pure string logic   (global ZSParse)
core/main.js          agentic loop, UI, camouflage, session state      (uses ZSProvider)
providers/deepseek.js everything DeepSeek-specific: DOM selectors, generation
                      detection, send mechanics, composer modes…       (global ZSProvider)
providers/gemini.js   same interface for Google Gemini (Angular DOM, Quill
                      composer, code-block masking)                    (global ZSProvider)
providers/kimi.js     same interface for Kimi / Moonshot AI (Vue DOM, Lexical
                      composer, segment-code masking)                  (global ZSProvider)
providers/glm.js      same interface for GLM / Z.ai (Svelte DOM, code-block
                      wrapper masking)                                 (global ZSProvider)
providers/qwen.js     same interface for Qwen / chat.qwen.ai (Vue DOM, network-tap
                      SSE stream, Monaco disposal guard)               (global ZSProvider)
providers/qwen-net.js MAIN-world fetch tap for Qwen SSE stream        (injected by manifest)
providers/arena.js    same interface for Arena / arena.ai (React DOM, multi-model
                      playground, A/B-comparison auto-commit, Direct-mode gate) (global ZSProvider)
providers/chatgpt.js, tokenwave.js, generic.js  same interface; generic.js carries per-host
                      selector profiles for 12 more sites + structural fallback
background.js         WebSocket to the local bridge (provider-agnostic)
```

`core/main.js` never touches the host site's DOM directly - it only calls the
`ZSProvider` interface. To integrate another AI site: write a new
`providers/<site>.js` exporting the same interface, then add its URL pattern to
`manifest.json` (`content_scripts` + `host_permissions`) and to
`PROVIDER_URLS` in `background.js`. No core change required.

Run `node test-parser.js` to smoke-test the command parser.

## Public distribution

This public build has no creator donation buttons or personal game-pass links in the interface. Project repository and setup tutorial links are provided as project resources.


## ZeroScript Free 1.8.4 — manual recovery and custom AI chats

### If the normal Roblox agent button fails
1. Open Roblox Studio, load a Place, and enable **Assistant AI → … → Manage MCP Servers → Enable Studio as MCP Server**.
2. Run `start.bat` from the `ZeroScript-Free` folder and keep its console window open.
3. Return to a supported AI chat tab where the ZeroScript overlay is visible.
4. Click **Ручной активатор Roblox** → **Проверить мост и инструменты**.
5. If the bridge is offline, click **Переподключить**, then check that `start.bat` is still running.
6. If the bridge responds but there are no tools, re-enable Studio's MCP server and make sure a Place is open.
7. When tools are listed, close the dialog and use the normal ZeroScript **Start session** button.

**Important:** copying `ws://127.0.0.1:17613` into an AI conversation does not connect that AI to your computer. `127.0.0.1` is local to the machine/runtime that opens it. This manual panel now tests the bridge from the browser extension and reports actual status instead of asking a chat model to pretend it can open a local WebSocket.

### My AI chats and search
- Use **Поиск ИИ** to filter the built-in directory and custom chat rows.
- Use **Поиск в My AI chats** to filter only your saved custom chat entries.
- A valid URL is not the same as a supported automation provider. The URL check reports address syntax; the live test is still manual.
- A custom URL is stored only when you explicitly press **Добавить чат**. It is not added to the built-in/general AI directory automatically.
- **Открыть** requests permission for that site's origin, opens the page, waits for it to finish loading, and then tries the generic adapter. This is experimental: selectors can differ, and sign-in, CAPTCHA, shadow DOM, or site changes may prevent automation.
- **Автонастройка** opens the selector panel. On the actual AI chat tab, click **Найти автоматически**, review the candidates, press **Сохранить**, and test with a harmless message. If candidates are wrong, use **Ручная настройка** and the selector help links.
- Google AI Mode URLs can be saved as a custom chat by the user, but this release deliberately does not hard-code any private/test URL into the built-in directory. The generic adapter is an attempt, not a guarantee of compatibility.

### Troubleshooting a chat that opens but does not respond
1. Confirm the ZeroScript bar is visible on that exact tab. If not, reload the extension at `chrome://extensions` / `edge://extensions`, grant the site's permission, and reload the chat page.
2. Open **Switch AI and options → My AI chats → Настроить селекторы**.
3. Run **Найти автоматически**, then inspect all three fields: input, send button, and assistant response.
4. Save selectors and test again. The response selector must point to the actual assistant message container, not the entire page.
5. If the site's markup is rendered in a closed shadow root or its terms/anti-bot controls prevent scripted input, this generic adapter cannot make it compatible; use one of the native supported providers listed in the main README.

- Use **Импорт настроек** to load a previously exported `zeroscript-ai-settings.json`. Imported entries are merged only into **My AI chats**, never into the built-in directory.


### ZeroScript 1.8.9 — подключение каталога

При выборе сайта из каталога расширение запрашивает разрешение на его домен. Для поддерживаемых встроенных сайтов используется профильный адаптер; для остальных включается общий адаптер на разрешённом домене, который сохраняется после перезагрузки. Если сайт является только страницей продукта/API-консолью или не имеет доступного чата, автоматическая интеграция не гарантируется: открой именно веб-чат и воспользуйся «Ручной настройкой» для селекторов поля ввода, кнопки отправки и ответа.
