## 1.9.1 — 2026-10-11\n- Replaced the recovery-only manual activator entry point with a guided 3-stage activation wizard: bootstrap/list_commands, list connected Roblox Studio instances, and verify Studio state.\n- The wizard explicitly distinguishes manual navigation from a confirmed connection and requires real command results before claiming readiness.\n- Made the in-chat color/theme shortcut visibly read “🎨 Цвета” and widened its button for easier discovery. The existing 1024-shade palette, presets, preview, save, and reset remain available.\n\n## 1.9.0 — 2026-10-11
- Добавлен быстрый доступ 🎨 к разделу «Цвета и темы» из панели ZeroScript.
- Добавлено копирование полного промпта ручной активации в окне ручного активатора.
- Кнопка копирования явно сообщает, что промпт нужно вручную вставить и отправить в чат; она не запускает мост и не отправляет сообщения автоматически.

## 1.8.9 — 2026-10-11

- Каталог ИИ теперь запускает подключение для выбранного сайта, а не только для Google AI Mode.
- Для сайтов без встроенного адаптера общий адаптер регистрируется на разрешённом домене и сохраняется после перезагрузки/перехода по страницам.
- Для сайтов со встроенным провайдером сохраняется специализированная интеграция.
- Совместимость не объявляется гарантированной: страницы без чата, авторизация, CAPTCHA и изменяющаяся разметка требуют ручной проверки/селекторов.

# Changelog

## 1.8.8 — AI integration repair
- Manual CSS selectors are now consumed by the generic adapter for input, send button, and assistant response. Changes in saved site profiles update the adapter without reloading.
- Added a dedicated experimental Google AI Mode profile for `https://www.google.com/search?udm=50`. It is injected only when explicitly launched from the ZeroScript directory, rather than on every Google search.
- Added Google host permission for the opt-in integration flow. This does not bypass login, CAPTCHA, site changes, or provider restrictions.
- The catalog's Google AI Mode entry now launches the opt-in integration flow and reports injection errors honestly.


## v1.8.7 — Color Studio
- Added a color/theme editor inside the extension menu.
- Separate controls for panel background, border, accent/buttons, text and glow.
- Added 20 preset styles, animation and rainbow-border options.
- Added a paginated 1024-shade palette, instant preview, save and reset.
- Theme preferences persist in `chrome.storage.local`.

## 1.8.6 — Google AI Mode in shared directory

- Added **Google AI Mode (тест)** to the shared AI directory, using the Google AI Mode search URL (`https://www.google.com/search?udm=50`).
- Kept the v1.8.5 step-by-step manual recovery flow.
- Note: this adds a directory shortcut; it does not by itself certify that ZeroScript can automate the Google AI Mode page.

## 1.8.5 — Step-by-step manual recovery

- Added a sequential recovery flow for bridge-stopped errors: restart bridge, verify the open Studio place, enable MCP, then verify tool discovery.
- Added a separate manual-task mode for continuing the original task without MCP using one concrete user-performed step or code snippet at a time.
- Clarified that prompts are copied for the user to send, and that a regular AI chat cannot launch local programs or execute Studio actions while the bridge is offline.
- Manual status checks distinguish bridge reachability from tool-list availability; neither is presented as proof that a tool command has executed.

## 1.8.4
- Added a manual recovery action directly to the bridge-disconnected banner.
- Manual recovery now gives a sequential, step-by-step prompt for the AI and explicit bridge/MCP verification steps.
- start.bat now retries the bridge process after an unexpected exit; Ctrl+C stops the watchdog.

# Changelog

## 1.8.3
- Added a separate search field for saved entries in **My AI chats**.
- Reworked the manual Roblox activator: it now checks real bridge status and MCP tool availability instead of implying that pasting a localhost WebSocket URL into a chat can connect it.
- Fixed custom AI adapter injection racing page navigation; the extension waits for the tab to finish loading.
- Clarified URL validation versus live automation compatibility.
- Kept user test URLs out of the built-in AI directory.

# Changelog

All notable changes to ZeroScript Free are documented here.

## [1.5.0]

### Added
- New providers: ChatGPT, TokenWave and `providers/generic.js`, one provider with
  per-host profiles for Claude, Grok, Mistral, Perplexity, Copilot, HuggingChat,
  Poe, DeepAI, ChatAI, ChatbotChatApp, Alice (Yandex) and QuillBot.
- Structural fallback in `generic.js`: finds the chat list from the text ZeroScript
  sent when the site's turn selectors match nothing.
- Site switcher lists all new sites; `overlay.css` keeps command blocks hidden after
  React-style re-renders (`.zs-cmd-mask-pre`).

### Notes
- The new providers have not been run against the live sites; adjust the selectors in
  the provider file if a site's markup differs.

## [1.4.1] - 2026-07-11

Robustness release focused on the Roblox Studio connection lifecycle. Every
fix below was reproduced and validated live against a real Studio + Blender
setup, including the Roblox-side bugs reported on the devforum (StudioMCP
stale-pipe disconnects, MCP toggle turning off after a Studio update).

### Fixed
- **Phantom "Studio connected" state**: leftover `StudioMCP.exe` processes
  from a previous session or a Studio crash kept answering the bridge as if a
  Studio were attached, so the terminal and the extension showed green with
  Studio fully closed. The bridge now kills orphaned `StudioMCP.exe` at boot
  (only when no real Studio window exists, so a live connection can never be
  hit), and the boot banner re-confirms a positive probe before announcing a
  connection.
- **Status dot stuck green with Studio closed**: when StudioMCP advertised an
  empty tool catalogue (Studio closed at launch), the connectivity probe
  returned "unknown" instead of "disconnected", and the extension's
  don't-degrade-on-unknown rule kept the dot green forever. An alive Roblox
  proxy with an empty catalogue is now an authoritative "not connected".
- **Studio opened after the bridge was never detected** (yellow until a full
  bridge restart): two combined causes. (1) Nothing ever re-asked for the
  tool catalogue once the launch-time retry window expired - the watcher now
  re-polls `tools/list` while the catalogue is empty, so a late-attaching
  Studio is picked up within seconds. (2) Studio's MCP plugin registers with
  the MCP channel exactly ONCE (late in Studio's boot, or when the Assistant
  Settings > MCP Servers panel is opened/toggled) and never retries; the
  bridge's own recovery restarts could kill the MCP listener at that exact
  moment, permanently orphaning the plugin. The bridge no longer restarts the
  Roblox proxy while a Studio window is running, and both the terminal and
  the extension now say the one thing that actually fixes an orphaned
  plugin: open Assistant Settings > MCP Servers in Studio (validated three
  times live; a proxy-side restart provably cannot repair it).
- **Watcher crash silently disabling all Studio monitoring**: an unbound
  variable in the place-churn detector could kill the background watcher
  right after a reconnect, silently stopping every status update until the
  next bridge restart. Fixed, and both watchers are now supervised: a crash
  is logged in red and the watcher restarts itself in 5 seconds.
- Boot/connection messages no longer blame the merged multi-server tool count
  on Roblox ("49 tools loaded but NO Roblox Studio connected" when 22 of
  those were Blender's): every Roblox-specific message now uses the
  Roblox-only count.

### Added
- **Fast startup with addon servers**: MCP servers now launch in parallel and
  the extension-facing socket opens immediately, so a slow or absent Roblox
  Studio no longer delays Blender (or any addon) by up to a minute. The
  Roblox diagnostic continues in the background and the bridge pushes status
  updates to already-connected extensions as servers come up - previously an
  extension that connected early could keep a stale "addon offline" snapshot
  forever (greyed Start button instead of the orange degraded start).
- **Self-healing for Roblox's own disconnect bugs**: sustained loss of the
  Studio connection (stale named-pipe state, periodic silent disconnects)
  now auto-restarts the Roblox proxy - but only when no Studio window is
  running, where it is safe and effective.
- **Studio-update detection**: when a disconnect coincides with a new Studio
  version folder appearing, the terminal says Studio likely turned its MCP
  toggle off after updating (a known Roblox bug) and points at the exact
  setting, instead of retrying a recovery that cannot work.
- Extension messages distinguish "Roblox Studio is not running" from "Studio
  is running but not connected" (new `studio_proc` status field), each with
  its own corrective step.
- Terminal spinner during slow startup phases (server launch, Studio
  attach), so the console never looks frozen; only one spinner animates at a
  time.
- start.bat hardening: refuses to run from an unextracted ZIP, handles
  missing winget, rescans install folders after a winget install (PATH not
  refreshed), prints the Python version and the bridge's exit code on
  screen, and logs the Windows build - so a single screenshot of the
  terminal carries enough context for support.

## [1.4.0] - 2026-07-08

### Added
- Multi-MCP addon servers (experimental): a new "MCP servers" section in the
  panel menu lets you add or remove additional MCP servers (Blender,
  Sketchfab, or any local MCP command) alongside the always-primary Roblox
  Studio connection. The bridge rewrites `config.json` and restarts itself to
  load a change; Roblox stays protected from edits/removal and its status dot
  is scoped to Roblox alone so an addon going down never misrepresents the
  primary connection. New `list_mcp_servers` command and a `server` param on
  `list_commands` let the model discover and use addon tool sets on demand.
  When Roblox is down but an addon server is alive, the panel now offers a
  degraded start instead of refusing to start at all.
- Vision support (screen_capture / other tool-returned images) enabled for
  Arena, Gemini, GLM, Kimi and Qwen, each with a real "upload finished" signal
  before sending instead of trusting the first local preview, fixing several
  silent-attachment-drop and duplicate-attachment-on-retry bugs. A tool from
  any connected server that returns an image now gets the camera chip and is
  remembered for future calls, even for a custom MCP server whose name gives
  no hint it returns images.
- Parser: a JSON command cut off by the model's own output limit, missing
  only its trailing closing brackets, is now auto-completed and executed
  instead of failing with a parse error and forcing a full retry turn.
  Strictly refuses to salvage anything where real content (not just closers)
  was cut off.
- Per-reason parse-error feedback (cut off, bad JSON, missing ###LUA###
  opener, wrong envelope) instead of one generic "bad JSON" message, so the
  model fixes the actual problem instead of guessing.

### Fixed
- DeepSeek: a command's chip could show green "done" while DeepSeek was still
  streaming the reply, on back-to-back calls to the same tool. Caused by
  DeepSeek's list virtualization defeating the turn-count identity guard;
  fixed with a stable per-turn id.
- GLM: new "scroll to bottom" buttons were mistaken for the Stop button and
  permanently latched generation state to "busy." Raw command JSON could leak
  into the visible reply when nested inside a paragraph. An image filename
  could corrupt result-chip detection.
- Kimi: added detection of Kimi's own native "Agent" mode, which conflicts
  with ZeroScript's command protocol; Start is disabled with a warning until
  it's turned off. Fixed the hidden file-upload input not existing until the
  "+" menu is opened, raw command text leaking when nested/oversized, and
  normal model prose containing "try again" being misread as a site error.
- Qwen: same "try again" false-busy fix as Kimi. A/B "carousel" comparison
  turns (where the composer disappears mid-carousel) now auto-resolve to
  Response 1 once both candidates finish, instead of stalling or misreading a
  candidate as a truncated command.
- Arena: send is now confirmed until the composer actually clears instead of
  trusting a single click, preventing stranded messages/attachments; the chip
  now anchors below the reply text instead of floating above it.
- A command turn abandoned mid-stream (reload, or superseded by a
  regenerate) no longer shows a false green checkmark; it now shows a
  neutral "not run" state instead.
- A tool's own in-body error (e.g. "Output of '...': Error executing code...")
  now settles the chip red instead of green, even when the tool didn't use
  ZeroScript's own ERROR wrapper.
- Regenerating a stopped command no longer briefly re-shows the old call's
  chip before the new one streams in.

### Changed
- The version number next to the ZeroScript name in the panel is now small,
  plain text instead of a bordered green badge.
- System prompt updated to cover multiple MCP servers: the model must call
  `list_mcp_servers` before assuming something outside Roblox is unsupported,
  and the tool list is no longer inlined in the prompt (fetched on demand via
  `list_commands`).

## [1.3.9] - 2026-07-04

### Fixed
- Bridge: kill the full process tree on restart instead of just the wrapper
  process, which used to leave orphaned StudioMCP.exe instances behind that
  fought the next launch and caused seemingly random "Studio looks connected
  but nothing responds" failures.
- Bridge: a dead MCP server is now auto-restarted by a background watchdog
  instead of waiting for the next tool call to notice.
- Bridge: a tool call that hits one of Studio's own brief connection blips now
  retries once instead of surfacing a spurious "Studio not connected" error.
- Extension: the status bar no longer shows a falsely healthy "N tools" label
  when the agent is active but Studio, the place, or the bridge itself isn't
  actually usable, it now names the real blocker (open a place / enable the
  MCP server / bridge offline).
- Cross-provider: DeepSeek, Gemini, Kimi, GLM and Qwen composer menus, model
  pickers and tooltips (including GLM's search hover card and Kimi's model
  popover) no longer render clipped or hidden behind ZeroScript's own
  bar/pill/cover.
- Cross-provider: a thinking model quoting command JSON in its own reasoning
  area no longer makes the tool chip flap between done/run/done (Gemini, Kimi,
  GLM and Qwen).
- The "Agent is working" composer cover now blocks clicks into the composer
  underneath it instead of letting them through, and can no longer balloon
  past the composer's visible band or drag itself off position when a site
  recreates its editor node mid-session (seen on Kimi).
- A command chip could briefly flash or restart its spinner when revisiting a
  past turn; it now settles to done correctly instead.
- DeepSeek: the raw system-prompt turn no longer flashes for a frame before
  being hidden.
- Gemini: "New chat" no longer gets stuck on "Agent active" from a reused
  previous conversation URL.
- Kimi: reasoning is read separately from the actual reply, so a command
  drafted while the model is still "thinking" is no longer detected or
  executed; input can no longer be typed mid-run after the editor node is
  recreated.
- Arena: unsupported-mode gate now also covers Web Search and Generate Image,
  and chip alignment is fixed when a command turn renders as an A/B
  model-comparison carousel.
- Bridge: a long-running tool call no longer starves the connection's ping
  handling and trips the half-open-socket watchdog.

### Changed
- Bridge and installer logs moved to `logs/bridge_debug.log` and
  `logs/start.log`; the console now only shows what a user actually needs to
  read, full detail still lands in the log files.
- `start.bat` now detects and explains a double launch instead of silently
  replacing the previous instance, and warns clearly if port 17613 stays held
  after trying to free it.
- Removed remaining em dashes from user-visible strings.
- Removed remaining em dashes from user-visible strings.

## [1.3.3] - 2026-06-24

### Fixed
- Bridge no longer depends on Roblox's `mcp.bat`, which hard-coded a single
  Studio version path and broke (0 tools / "Bridge or Studio offline") once
  Studio auto-updated and that version folder was removed. A new
  `launch_studio_mcp.py` finds the newest installed `StudioMCP.exe` and launches
  it directly.
- `bridge.py` now runs a `.py` MCP command with the same Python interpreter as
  the bridge, so it works on installs where only the `py` launcher exists.

## [1.0.0] - 2026-06-09

### Added
- Initial public release of ZeroScript Free
- Browser extension for Chrome and Edge (DeepSeek chat integration)
- Local Python bridge (`bridge.py` + `start.bat`) for Roblox Studio communication
- Built-in MCP server support (no plugin required - activate directly in Roblox Studio)
- Read and edit Luau scripts directly from DeepSeek chat
- Run Luau code in real time inside Roblox Studio
- Inspect game tree and instances
- Generate meshes, materials, and models
- Browse and insert assets from the Creator Store
- Control play-testing from chat
- Panel status indicator (green / yellow / grey)
- Auto kill port 17613 on start to avoid conflicts
- Ko-fi support link with Robux tip passes in the extension panel
- Setup tutorial video on YouTube


## 1.7.0 — Custom AI chat directory

- Added a menu section to save and remove custom AI chat URLs.
- Added URL validation, manual chat test/open action, status symbols (✓ built-in provider host, ● valid but unverified, − invalid URL), and saved CSS selector profiles.
- Custom selector profiles are configuration only; a site-specific automation adapter is still required before arbitrary chats can control ZeroScript.

## 1.8.0 — Search and setup wizard

- Added a search field at the top of the AI directory to filter built-in and custom chat entries.
- Added separate manual and automatic setup controls, selector discovery for the active web page, detailed per-field help links, and an export-to-JSON settings button.
- Added opt-in per-origin permission requests and an experimental generic-adapter launch for custom AI chat URLs.
- Automatic discovery only proposes DOM selectors; it cannot guarantee a successful model response, inspect browser DevTools console logs, bypass authentication/CAPTCHA, or make every provider compatible. Review and test selectors before relying on automation.


## 1.8.1 — Position picker and visible fallback

- Added a click-to-select panel placement dialog, with disabled Save/Again buttons until a position is selected. Save stores/updates the profile by name; Again resets the marker.
- Keep the launcher visible if the provider adapter cannot find the chat composer.
- Added Copilot.com and www.chatgpt.com generic content-script matches.
- This does not guarantee all AI sites can be automated: site-specific DOM adapters and browser permissions are still required.
