## v1.8.8 AI Integration Repair (includes Color Studio)
Open the ZeroScript menu and use “Цвета и темы” to customize panel background, borders, buttons/accent, text and glow. Choose among 20 presets, browse 1024 generated shades, enable animation/rainbow border, preview, save, or reset. Preferences persist locally in the browser extension.

# ZeroScript Free - AI Roblox Studio Agent (DeepSeek, Gemini, Kimi, GLM, Qwen, Arena, ChatGPT, TokenWave + 12 more)

Control Roblox Studio with AI, for free. ZeroScript turns a normal AI chat (DeepSeek, Google Gemini, Kimi, GLM, Qwen, or Arena) into an agent that builds and scripts your Roblox game for you: just describe what you want, and it reads/edits scripts, runs Luau, inspects the game tree, and generates assets directly in Roblox Studio. No API key, no terminal, no coding required.

It's a Chrome/Edge browser extension plus a small local bridge that connects the chat to Roblox Studio through the official MCP server. Gemini, Kimi, GLM, Qwen and Arena also work but can be less stable: Gemini tends to stop using the Roblox tools in long sessions, and Kimi sometimes reaches for its own native tools instead of the Roblox commands. On Arena, keep the mode dropdown on **Direct** (ZeroScript only supports Direct mode).

## Setup

**Load the extension manually (Edge or Chrome):**
1. Go to `edge://extensions` (Edge) or `chrome://extensions` (Chrome)
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `zeroscript-extension` folder
5. The extension is now active

**Then set up the Bridge:**
1. **Download the Bridge** from the [GitHub releases page](https://github.com/sebattfg/ZeroScript-Free)
2. **Open Roblox Studio** and load a Place
3. **Enable the MCP server in Roblox Studio** (first time only): click **Assistant AI** in the top bar, then **...** > **Manage MCP Servers** > **Enable Studio as MCP Server**
4. **Run start.bat** - a small window opens, the Bridge is running
5. **Go to https://chat.deepseek.com** (recommended), https://gemini.google.com, https://www.kimi.com, https://chat.z.ai, https://chat.qwen.ai, or https://arena.ai, open a new chat (only works on these exact addresses; on Arena use Direct mode)
6. Click **Start session** in the ZeroScript panel
7. Type what you want to build

📺 [Watch the setup tutorial](https://youtu.be/kPKiZLZ9_Ps)

## Supported sites

| Provider file | Sites |
|---|---|
| `deepseek.js`, `gemini.js`, `kimi.js`, `glm.js`, `qwen.js`, `arena.js` | DeepSeek, Gemini, Kimi, GLM, Qwen, Arena (tested by the original author) |
| `chatgpt.js` | chatgpt.com |
| `tokenwave.js` | tokenwave.ru/chat (sign in / add your API key on the site first) |
| `generic.js` | Claude (claude.ai), Grok, Mistral, Perplexity, Copilot, HuggingChat, Poe, DeepAI, ChatAI, ChatbotChatApp, Alice (alice.yandex.ru), QuillBot |

**Not live-tested:** ChatGPT, TokenWave and everything handled by `generic.js` were written without browser access, so their selectors are best effort. `generic.js` has a built-in fallback that locates the chat list from the text ZeroScript sent, which helps when a site's markup differs from the profile. If a site misbehaves, edit only its entry in `PROFILES` at the top of `providers/generic.js`.

## Architecture (for contributors)

The extension is split between a provider-agnostic core and per-AI-site providers:

```
core/config.js        system prompt, feedback strings, tool categories (global ZS)
core/parser.js        ZeroScript command parsing - pure string logic   (global ZSParse)
core/main.js          agentic loop, UI, camouflage, session state      (uses ZSProvider)
providers/deepseek.js everything DeepSeek-specific: DOM selectors, generation
                      detection, send mechanics, composer modes…       (global ZSProvider)
providers/gemini.js   same interface for Google Gemini (Angular DOM, Quill
                      composer, code-block masking)                    (global ZSProvider)
providers/kimi.js     same interface for Kimi / Moonshot AI (Vue DOM, Lexical
                      composer, segment-code masking)                  (global ZSProvider)
providers/glm.js      same interface for GLM / Z.ai (Svelte DOM, code-block
                      wrapper masking)                                 (global ZSProvider)
providers/qwen.js     same interface for Qwen / chat.qwen.ai (Vue DOM, network-tap
                      SSE stream, Monaco disposal guard)               (global ZSProvider)
providers/qwen-net.js MAIN-world fetch tap for Qwen SSE stream        (injected by manifest)
providers/arena.js    same interface for Arena / arena.ai (React DOM, multi-model
                      playground, A/B-comparison auto-commit, Direct-mode gate) (global ZSProvider)
providers/chatgpt.js, tokenwave.js, generic.js  same interface; generic.js carries per-host
                      selector profiles for 12 more sites + structural fallback
background.js         WebSocket to the local bridge (provider-agnostic)
```

`core/main.js` never touches the host site's DOM directly - it only calls the
`ZSProvider` interface. To integrate another AI site: write a new
`providers/<site>.js` exporting the same interface, then add its URL pattern to
`manifest.json` (`content_scripts` + `host_permissions`) and to
`PROVIDER_URLS` in `background.js`. No core change required.

Run `node test-parser.js` to smoke-test the command parser.

## Public distribution

This public build has no creator donation buttons or personal game-pass links in the interface. Project repository and setup tutorial links are provided as project resources.


## AI directory and compatibility note (v1.6.0)

The ZeroScript panel includes 200+ AI website launch links. A launch link opens the service; it does **not** mean every listed service is integrated with ZeroScript's Roblox Studio agent. Agent automation currently depends on a site-specific provider and may need maintenance when a website changes its interface. ChatGPT and Microsoft Copilot are shown as clickable buttons even while you are already on those sites. GigaChat and Nika Agent have been added to the generic provider as best-effort integrations; their selectors have not been verified against every live page state.


## Manual activation fallback (v1.8.2)

The provider bar includes a **Manual Roblox Activator** button beneath the main agent controls. It displays the local bridge address and a copyable prompt for troubleshooting. Pasting a WebSocket address into an ordinary AI chat does not grant that AI local network/MCP access; the AI environment must explicitly support the connection. A custom AI URL that parses correctly is labelled as a valid URL even when its automation selectors/provider have not been verified. Custom test URLs are saved only in **My AI chats** and are not added to the general AI directory.


### Version 1.8.8 integration notes
The generic provider now consumes saved manual selectors (input, send, assistant response) for the matching hostname. Google AI Mode is an opt-in experimental integration launched from the catalog; it is not injected into ordinary Google Search tabs. Successful script injection is not proof that a provider accepts messages or exposes responses.
