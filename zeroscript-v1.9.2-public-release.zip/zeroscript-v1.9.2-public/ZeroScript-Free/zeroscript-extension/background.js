// SPDX-License-Identifier: GPL-3.0-or-later
// background.js - service worker.
// Owns ONE resilient WebSocket to the local bridge (ws://127.0.0.1:PORT).
// Keeping the socket here (not in the content script) avoids https→ws mixed
// content issues and centralises reconnect / timeout logic.
//
// Contract with content.js: every sendMessage ALWAYS gets a response object,
// even when the bridge is offline. The agentic loop must never hang waiting.

const PORT = 17613;
const URL = `ws://127.0.0.1:${PORT}`;

// Chat sites where a ZeroScript provider content script runs. Status pushes go
// to every tab matching these. Add the new provider's URL pattern here (and in
// manifest.json content_scripts + host_permissions) when integrating another AI.
const PROVIDER_URLS = [
  "https://www.nika-agent.ru/*",
  "https://nika-agent.ru/*",
  "https://giga.chat/*","https://chat.deepseek.com/*", "https://gemini.google.com/*", "https://www.kimi.com/*", "https://kimi.com/*", "https://chat.z.ai/*", "https://chat.qwen.ai/*", "https://arena.ai/*", "https://chatgpt.com/*", "https://chat.openai.com/*", "https://tokenwave.ru/*", "https://alice.yandex.ru/*", "https://chat.mistral.ai/*", "https://chatai.org/*", "https://chatbotchatapp.com/*", "https://claude.ai/*", "https://copilot.microsoft.com/*", "https://deepai.org/*", "https://grok.com/*", "https://huggingface.co/*", "https://perplexity.ai/*", "https://poe.com/*", "https://quillbot.com/*", "https://www.chatai.org/*", "https://www.chatbotchatapp.com/*", "https://www.perplexity.ai/*", "https://www.google.com/search*"];

const RECONNECT_MIN = 1000;
const RECONNECT_MAX = 5000;
const HEARTBEAT_MS = 10000;
// If no message (incl. pong) arrives within this window while we believe we're
// connected, the socket is half-open: force a reconnect instead of letting
// pending requests slowly time out.
const STALE_SOCKET_MS = 25000;
const REQUEST_TIMEOUT_DEFAULT = 130000; // a bit above the 120s tool timeout

let ws = null;
let connected = false;
let reconnectDelay = RECONNECT_MIN;
let reconnectTimer = null;
let heartbeatTimer = null;
let lastMessageAt = 0; // timestamp of the last frame received from the bridge
let nextId = 1;
const pending = new Map(); // id -> {resolve, timer}
let toolsCache = [];
let mcpAlive = false;
let serversCache = [];
// true/false = a PLACE is loaded and usable in Roblox Studio; null = unknown.
// The MCP process stays alive when Studio is closed or its MCP option is off,
// so this is probed separately (bridge "studio_status").
let studioConnected = null;
// true/false = a Roblox Studio app is connected to the MCP server at all; null =
// unknown. studioApp=true with studioConnected=false means "Studio open but no
// place"; studioApp=false means "Studio closed OR its MCP option disabled".
let studioApp = null;
// true/false = a Roblox Studio WINDOW/PROCESS exists on this machine (checked
// bridge-side via tasklist); null = unknown/old bridge. Distinguishes the two
// studioApp=false sub-cases the UI must word differently: Studio genuinely not
// launched ("open Roblox Studio") vs Studio OPEN but its MCP plugin never
// registered with the bridge - the documented fix for the latter is opening
// Assistant Settings > MCP Servers inside Studio (validated live 3x), which
// "open Roblox Studio" wording completely fails to convey.
let studioProc = null;

function log(...a) {
  console.log("[zs-bg]", ...a);
}

// ── WebSocket lifecycle ─────────────────────────────────────────────────
function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  clearTimeout(reconnectTimer);
  try {
    ws = new WebSocket(URL);
  } catch (e) {
    log("WebSocket ctor failed", e);
    scheduleReconnect();
    return;
  }

  ws.onopen = () => {
    connected = true;
    reconnectDelay = RECONNECT_MIN;
    lastMessageAt = Date.now();
    log("connected to bridge");
    startHeartbeat();
    broadcastStatus();
  };

  ws.onmessage = (ev) => {
    lastMessageAt = Date.now();
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    handleBridgeMessage(msg);
  };

  ws.onclose = () => {
    connected = false;
    mcpAlive = false;
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    serversCache = [];
    stopHeartbeat();
    failAllPending("bridge connection closed");
    broadcastStatus();
    scheduleReconnect();
  };

  ws.onerror = () => {
    // onclose will follow; nothing to do here but avoid an unhandled error.
    try { ws.close(); } catch {}
  };
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 1.7, RECONNECT_MAX);
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (connected) {
      // Half-open socket: the WS still reports OPEN but nothing comes through.
      // The pong (and every other frame) refreshes lastMessageAt; if it has
      // gone stale, drop the dead socket so onclose triggers a reconnect.
      if (lastMessageAt && Date.now() - lastMessageAt > STALE_SOCKET_MS) {
        log("socket stale, forcing reconnect");
        try { ws.close(); } catch {}
        return;
      }
      // Keeps the MV3 service worker alive AND detects a half-open socket.
      send({ type: "ping" }).catch(() => {});
      refreshStudioStatus();
    }
  }, HEARTBEAT_MS);
}

function stopHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

// Resolve once the socket is OPEN, or false after `timeout` ms.
function waitForConnection(timeout = 8000) {
  return new Promise((resolve) => {
    if (connected && ws && ws.readyState === WebSocket.OPEN) return resolve(true);
    connect(); // nudge a (re)connection - important after a worker wake-up
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (connected && ws && ws.readyState === WebSocket.OPEN) {
        clearInterval(iv);
        resolve(true);
      } else if (Date.now() - t0 > timeout) {
        clearInterval(iv);
        resolve(false);
      }
    }, 100);
  });
}

// ── request/response over the socket ────────────────────────────────────
async function send(obj, timeout = REQUEST_TIMEOUT_DEFAULT) {
  // The MV3 service worker can be suspended; the first message after a wake-up
  // arrives before the socket has re-opened. Wait for it instead of failing -
  // otherwise Kimi wrongly hears "bridge offline".
  if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
    await waitForConnection(8000);
  }
  return new Promise((resolve) => {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
      resolve({ ok: false, kind: "disconnected", error: "bridge not connected" });
      return;
    }
    const id = nextId++;
    const payload = { ...obj, id };
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        resolve({ ok: false, kind: "timeout", error: "bridge did not respond in time" });
      }
    }, timeout);
    pending.set(id, { resolve, timer });
    try {
      ws.send(JSON.stringify(payload));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      resolve({ ok: false, kind: "disconnected", error: String(e) });
    }
  });
}

// Ask the bridge whether a Roblox Studio instance is actually connected to the
// MCP server. Broadcasts only on change so the UI updates promptly but quietly.
let studioProbing = false;
async function refreshStudioStatus() {
  if (studioProbing || !connected) return;
  studioProbing = true;
  try {
    const r = await send({ type: "studio_status" }, 12000);
    const v = r && r.ok && typeof r.studio === "boolean" ? r.studio : null;
    if (v !== studioConnected) {
      studioConnected = v;
      broadcastStatus();
    }
  } finally {
    studioProbing = false;
  }
}

function handleBridgeMessage(msg) {
  if ("studio" in msg && (typeof msg.studio === "boolean" || msg.studio === null)) {
    studioConnected = msg.studio;
  }
  if ("studio_app" in msg && (typeof msg.studio_app === "boolean" || msg.studio_app === null)) {
    studioApp = msg.studio_app;
  }
  if ("studio_proc" in msg && (typeof msg.studio_proc === "boolean" || msg.studio_proc === null)) {
    studioProc = msg.studio_proc;
  }
  if (msg.type === "studio_status") {
    resolvePending(msg.id, { ok: true, studio: studioConnected });
    broadcastStatus();
    return;
  }
  if (msg.type === "connected") {
    mcpAlive = !!msg.mcp_alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    broadcastStatus();
    return;
  }
  if (msg.type === "pong") {
    resolvePending(msg.id, { ok: true });
    return;
  }
  if (msg.type === "tools") {
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    mcpAlive = !!msg.mcp_alive;
    resolvePending(msg.id, { ok: true, tools: toolsCache });
    broadcastStatus();
    return;
  }
  if (msg.type === "tool_result") {
    resolvePending(msg.id, msg.ok
      ? { ok: true, text: msg.text, images: msg.images || [] }
      : { ok: false, kind: msg.kind, error: msg.error });
    return;
  }
  if (msg.type === "mcp_status") {
    mcpAlive = !!msg.alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    resolvePending(msg.id, { ok: !!msg.ok, alive: msg.alive, error: msg.error });
    broadcastStatus();
    return;
  }
  if (msg.type === "server_changed") {
    // The bridge acks, then restarts itself to reload config.json. The socket
    // will drop right after this - the content script shows a spinner until the
    // reconnect lands and a fresh status arrives.
    resolvePending(msg.id, { ok: !!msg.ok, error: msg.error, restarting: !!msg.restarting });
    return;
  }
  if (msg.type === "error") {
    resolvePending(msg.id, { ok: false, error: msg.error });
    return;
  }
}

function resolvePending(id, value) {
  const p = pending.get(id);
  if (!p) return;
  clearTimeout(p.timer);
  pending.delete(id);
  p.resolve(value);
}

function failAllPending(reason) {
  for (const [, p] of pending) {
    clearTimeout(p.timer);
    p.resolve({ ok: false, kind: "disconnected", error: reason });
  }
  pending.clear();
}

// ── status push to any open DeepSeek tab + popup ─────────────────────────
function statusObj() {
  return { type: "zs-status", connected, mcpAlive, studio: studioConnected, studioApp, studioProc, tools: toolsCache.length, servers: serversCache };
}

function broadcastStatus() {
  chrome.runtime.sendMessage(statusObj()).catch(() => {});
  chrome.tabs.query({ url: PROVIDER_URLS }, (tabs) => {
    for (const t of tabs) chrome.tabs.sendMessage(t.id, statusObj()).catch(() => {});
  });
}

// ── messages from content.js / popup.js ─────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "ZS_SCAN_ACTIVE_AI_PAGE": {
        const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        if (!tab || !tab.id || !tab.url || !/^https?:/.test(tab.url)) {
          sendResponse({ ok: false, error: "Открой обычную страницу чата (не chrome:// и не страницу расширения)." });
          break;
        }
        const originPattern = new URL(tab.url).origin + "/*";
        const granted = await chrome.permissions.request({ origins: [originPattern] });
        if (!granted) { sendResponse({ ok: false, error: "Разрешение для этого домена не выдано." }); break; }
        const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
          const visible = (el) => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
          const candidates = [...document.querySelectorAll('textarea, input:not([type]), input[type="text"], [contenteditable="true"], [role="textbox"]')].filter(visible);
          const input = candidates.find(el => !/search|filter/i.test((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || ''))) || candidates[0];
          const buttons = [...document.querySelectorAll('button, [role="button"]')].filter(visible);
          const send = buttons.find(el => /send|submit|отправить|послать/i.test((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-testid') || '')));
          const response = document.querySelector('[data-message-author-role="assistant"], [data-testid*="conversation-turn"], [class*="assistant-message"], [class*="message-content"], main [role="article"]');
          const cssPath = (el) => {
            if (!el) return '';
            for (const attr of ['data-testid','data-message-author-role','aria-label','name','id']) {
              const v = el.getAttribute(attr);
              if (v) {
                const sel = el.tagName.toLowerCase() + '[' + attr + '="' + CSS.escape(v) + '"]';
                try { if (document.querySelectorAll(sel).length === 1) return sel; } catch {}
              }
            }
            if (el.id) return '#' + CSS.escape(el.id);
            const tag = el.tagName.toLowerCase();
            const cls = [...el.classList].filter(Boolean).slice(0,2).map(c => '.' + CSS.escape(c)).join('');
            return tag + cls;
          };
          return { selectors: { input: cssPath(input), send: cssPath(send), response: cssPath(response) }, found: !!input && !!send && !!response, counts: { inputs: candidates.length, buttons: buttons.length, response: !!response } };
        }});
        sendResponse({ ok: true, ...results[0].result });
        break;
      }
      case "ZS_INSTALL_CUSTOM_AI": {
        let u;
        try { u = new URL(msg.url); } catch { sendResponse({ ok: false, error: "Некорректный адрес." }); break; }
        if (!/^https?:$/.test(u.protocol)) { sendResponse({ ok: false, error: "Разрешены только HTTP/HTTPS сайты." }); break; }
        // Ask for optional access during the click flow, but always navigate to
        // the chosen AI site even when the user declines automation permissions.
        const originPattern = u.origin + "/*";
        const alreadyGranted = await chrome.permissions.contains({ origins: [originPattern] });
        const granted = alreadyGranted || await chrome.permissions.request({ origins: [originPattern] });
        if (!granted) {
          const opened = await chrome.tabs.create({ url: u.href, active: true });
          sendResponse({ ok: true, tabId: opened.id, generic: false, note: "Сайт открыт. Разрешение для автоматизации не выдано, поэтому панель ZeroScript может не появиться на этом сайте." });
          break;
        }
        const tab = await chrome.tabs.create({ url: u.href, active: true });
        // tabs.create resolves before navigation completes. Injecting immediately
        // races the document load and commonly fails on slow AI pages.
        try {
          if (tab.status !== "complete") {
            await new Promise((resolve, reject) => {
              const timeout = setTimeout(() => { cleanup(); reject(new Error("Истекло время ожидания загрузки страницы.")); }, 30000);
              const cleanup = () => { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(onUpdated); };
              const onUpdated = (tabId, changeInfo) => {
                if (tabId === tab.id && changeInfo.status === "complete") { cleanup(); resolve(); }
              };
              chrome.tabs.onUpdated.addListener(onUpdated);
              chrome.tabs.get(tab.id, current => {
                if (current && current.status === "complete") { cleanup(); resolve(); }
              });
            });
          }
          // Persist a generic adapter for this explicitly approved origin. This
          // makes the integration survive reloads and client-side navigation.
          // Known native-provider origins keep their specialized adapter.
          const nativeHosts = new Set([
            "chat.deepseek.com", "deepseek.com", "gemini.google.com", "www.kimi.com", "kimi.com",
            "chat.z.ai", "chat.qwen.ai", "arena.ai", "chatgpt.com", "chat.openai.com", "tokenwave.ru",
            "claude.ai", "grok.com", "chat.mistral.ai", "www.perplexity.ai", "perplexity.ai",
            "copilot.microsoft.com", "huggingface.co", "poe.com", "deepai.org", "chatai.org",
            "www.chatai.org", "chatbotchatapp.com", "www.chatbotchatapp.com", "alice.yandex.ru",
            "quillbot.com", "giga.chat", "nika-agent.ru", "www.nika-agent.ru", "www.copilot.microsoft.com",
            "copilot.com", "www.copilot.com", "aistudio.google.com", "www.google.com"
          ]);
          const isGoogleAIMode = u.hostname === "www.google.com" && u.pathname === "/search" && u.searchParams.get("udm") === "50";
          const useGeneric = !nativeHosts.has(u.hostname) || isGoogleAIMode;
          if (useGeneric) {
            // Google AI Mode is a query-specific experience. Do not register a
            // persistent script on the whole Google origin; inject only into the
            // explicitly selected AI Mode tab. Other approved sites get a durable
            // origin registration so navigation/reloads keep working.
            if (!isGoogleAIMode) {
              const scriptId = "zs-generic-" + u.hostname.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 45);
              try { await chrome.scripting.unregisterContentScripts({ ids: [scriptId] }); } catch {}
              await chrome.scripting.registerContentScripts([{
                id: scriptId,
                matches: [originPattern],
                js: ["core/config.js", "core/parser.js", "providers/generic.js", "core/main.js"],
                css: ["overlay.css"],
                runAt: "document_idle",
                persistAcrossSessions: true
              }]);
            }
            // Inject immediately as registration applies to subsequent navigations.
            await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["core/config.js", "core/parser.js", "providers/generic.js", "core/main.js"] });
            await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["overlay.css"] });
          }
          sendResponse({ ok: true, tabId: tab.id, generic: useGeneric, note: useGeneric
            ? "Экспериментальный адаптер включён для домена и будет сохраняться после перезагрузки. Совместимость чата нужно проверить; если не распознаёт элементы, используй ручные селекторы."
            : "Открыт сайт со встроенным провайдером. Если панель не появилась, перезагрузи вкладку и проверь разрешение сайта." });
        } catch (e) { sendResponse({ ok: false, error: "Страница открыта, но адаптер не удалось внедрить: " + e.message }); }
        break;
      }
      case "status":
        if (!connected) connect(); // self-heal after a worker wake-up
        sendResponse(statusObj());
        break;
      case "list_tools": {
        // Prefer a live refresh; fall back to cache so the loop never stalls.
        const r = await send({ type: "list_tools" }, 25000);
        if (r.ok) sendResponse({ ok: true, tools: r.tools });
        else sendResponse({ ok: toolsCache.length > 0, tools: toolsCache, error: r.error });
        break;
      }
      case "call_tool": {
        const timeout = (msg.timeout || 120000) + 10000;
        const r = await send(
          { type: "call_tool", name: msg.name, arguments: msg.arguments, timeout: msg.timeout },
          timeout
        );
        sendResponse(r);
        break;
      }
      case "restart_mcp": {
        const r = await send({ type: "restart_mcp" }, 30000);
        sendResponse(r);
        break;
      }
      case "add_server": {
        const r = await send({
          type: "add_server", server_id: msg.server_id,
          command: msg.command, args: msg.args, env: msg.env,
        }, 15000);
        sendResponse(r);
        break;
      }
      case "remove_server": {
        const r = await send({ type: "remove_server", server_id: msg.server_id }, 15000);
        sendResponse(r);
        break;
      }
      case "reconnect":
        reconnectDelay = RECONNECT_MIN;
        connect();
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: "unknown message" });
    }
  })();
  return true; // async sendResponse
});

// Wake/keepalive hooks.
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);

connect();
