// SPDX-License-Identifier: GPL-3.0-or-later
// providers/generic.js - ONE provider for many chat sites (Claude, Grok, Mistral,
// Perplexity, Copilot, HuggingChat, Poe, DeepAI, ChatAI, ChatbotChatApp, Alice,
// QuillBot). Same ZSProvider interface as providers/chatgpt.js; core/main.js is
// untouched.
//
// How it adapts to a site:
//  1. PROFILES below hold per-host selector lists (editor / send / stop / user turn /
//     assistant turn). Every list is tried in order and the first visible match wins,
//     and each list ends with broad fallbacks, so a small markup change does not
//     break the provider.
//  2. If the user/assistant turn selectors match nothing, a STRUCTURAL fallback finds
//     the chat list by locating the text ZeroScript itself just sent, and treats the
//     list's children as turns (ours = user, the rest = assistant).
//  3. Sending uses the site's send button when found, otherwise Enter.
//
// Selectors here are written from knowledge of each site's public markup and were NOT
// run against the live sites (no browser access when this was written). If one site
// misbehaves, only its PROFILES entry needs to be adjusted.
//
// To DISABLE a site remove its host from manifest.json (content_scripts + host_permissions),
// from background.js PROVIDER_URLS and from AI_SITES in core/main.js.
// eslint-disable-next-line no-unused-vars
const ZSProvider = (() => {
  "use strict";
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let diag = () => {};

  // ── Per-site profiles ───────────────────────────────────────────────────
  const COMMON = {
    editor: [
      "#prompt-textarea",
      'div[contenteditable="true"][role="textbox"]',
      '.ProseMirror[contenteditable="true"]',
      'div[contenteditable="true"][data-placeholder]',
      "textarea[placeholder]",
      "textarea",
      'div[contenteditable="true"]',
    ],
    send: [
      'button[data-testid*="send" i]',
      'button[aria-label*="send" i]',
      'button[aria-label*="отправ" i]',
      'button[title*="send" i]',
      'button[title*="отправ" i]',
      'button[type="submit"]',
    ],
    stop: [
      'button[data-testid*="stop" i]',
      'button[aria-label*="stop" i]',
      'button[aria-label*="останов" i]',
      'button[aria-label*="cancel" i]',
      'button[title*="stop" i]',
      'button[title*="останов" i]',
    ],
    user: [
      '[data-message-author-role="user"]',
      '[data-testid="user-message"]',
      '[data-role="user"]',
      '[data-author="user"]',
      '[data-sender="user"]',
      '[data-testid*="user-message" i]',
      '[class*="user-message" i]',
      '[class*="message-user" i]',
      '[class*="UserMessage"]',
      '[class*="human" i][class*="message" i]',
      ".user-message",
    ],
    asst: [
      '[data-message-author-role="assistant"]',
      '[data-role="assistant"]',
      '[data-author="assistant"]',
      '[data-sender="bot"]',
      '[data-testid*="assistant" i]',
      '[data-testid*="bot-message" i]',
      '[class*="assistant-message" i]',
      '[class*="message-assistant" i]',
      '[class*="bot-message" i]',
      '[class*="message-bot" i]',
      '[class*="AssistantMessage"]',
      '[class*="ai-message" i]',
      '[class*="response-content" i]',
      ".assistant-message",
    ],
    codeWrap: ["div.contain-inline-size", "[class*='code-block' i]", "[class*='CodeBlock']", "[class*='codeblock' i]"],
    convRe: /\/(c|chat|chats|conversation|conversations|thread|t|app)\/[\w-]{6,}/i,
    vision: false,
  };

  const PROFILES = [
    {
      id: "claude", name: "Claude", hosts: ["claude.ai"], vision: true,
      editor: ['div[contenteditable="true"].ProseMirror', '[data-testid="chat-input"]', 'div[contenteditable="true"][role="textbox"]'],
      send: ['button[aria-label="Send message"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label="Stop response"]', 'button[aria-label*="Stop" i]'],
      user: ['[data-testid="user-message"]'],
      asst: ['[data-is-streaming]', ".font-claude-response", ".font-claude-message"],
      convRe: /\/chat\/[\w-]{8,}/,
    },
    {
      id: "grok", name: "Grok", hosts: ["grok.com"], vision: true,
      editor: ["textarea", 'div[contenteditable="true"].tiptap', 'div[contenteditable="true"]'],
      send: ['button[type="submit"]', 'button[aria-label="Submit"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label*="Stop" i]', 'button[aria-label*="Cancel" i]'],
      user: ['div[class*="message-bubble"]:not(:has(.response-content-markdown))', '[class*="items-end"] [class*="message-bubble"]'],
      asst: [".response-content-markdown", '[class*="message-bubble"]:has(.response-content-markdown)'],
      convRe: /\/chat\/[\w-]{8,}/,
    },
    {
      id: "mistral", name: "Mistral", hosts: ["chat.mistral.ai"], vision: true,
      editor: ['div[contenteditable="true"].ProseMirror', "textarea", 'div[contenteditable="true"]'],
      send: ['button[aria-label="Send question"]', 'button[aria-label*="Send" i]', 'button[type="submit"]'],
      stop: ['button[aria-label*="Stop" i]'],
      user: ['[data-message-author-role="user"]', '[data-testid="user-message"]'],
      asst: ['[data-message-author-role="assistant"]', '[data-testid="assistant-message"]'],
      convRe: /\/chat\/[\w-]{8,}/,
    },
    {
      id: "perplexity", name: "Perplexity", hosts: ["www.perplexity.ai", "perplexity.ai"], vision: true,
      editor: ["#ask-input", 'div[contenteditable="true"][role="textbox"]', "textarea"],
      send: ['button[aria-label="Submit"]', 'button[data-testid="submit-button"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label*="Stop" i]'],
      user: ['[class*="group/query"]', 'h1[class*="query"]', '[data-testid="user-query"]'],
      asst: ['[id^="markdown-content"]', '[class*="prose"]'],
      convRe: /\/search\/[\w-]{8,}/,
    },
    {
      id: "copilot", name: "Copilot", hosts: ["copilot.microsoft.com"], vision: true,
      editor: ["#userInput", "textarea", 'div[contenteditable="true"]'],
      send: ['button[data-testid="submit-button"]', 'button[aria-label="Submit message"]', 'button[aria-label*="Send" i]'],
      stop: ['button[data-testid="stop-button"]', 'button[aria-label*="Stop" i]'],
      user: ['[data-content="user-message"]', '[data-testid="user-message"]', 'div[data-author="user"]'],
      asst: ['[data-content="ai-message"]', '[data-testid="ai-message"]', 'div[data-author="bot"]'],
      convRe: /\/chats\/[\w-]{8,}/,
    },
    {
      id: "huggingchat", name: "HuggingChat", hosts: ["huggingface.co"], pathPrefix: "/chat",
      editor: ["textarea", 'div[contenteditable="true"]'],
      send: ['button[type="submit"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label*="Stop" i]', 'button[class*="stop" i]'],
      user: ['[data-message-role="user"]', '[data-message-author-role="user"]', 'div[class*="user"][class*="message" i]'],
      asst: ['[data-message-role="assistant"]', '[data-message-author-role="assistant"]', 'div[class*="prose"]'],
      convRe: /\/chat\/conversation\/[\w-]{8,}/,
    },
    {
      id: "poe", name: "Poe", hosts: ["poe.com"], vision: true,
      editor: ['textarea[class*="GrowingTextArea"]', "textarea"],
      send: ['button[class*="sendButton" i]', 'button[aria-label*="Send" i]', 'button[data-button-send]'],
      stop: ['button[class*="stop" i]', 'button[aria-label*="Stop" i]'],
      user: ['[class*="Message_rightSideMessageBubble"]', '[class*="humanMessage" i]'],
      asst: ['[class*="Message_leftSideMessageBubble"]', '[class*="botMessage" i]'],
      convRe: /\/chat\/[\w-]{6,}/,
    },
    {
      id: "deepai", name: "DeepAI", hosts: ["deepai.org"], pathPrefix: "/chat",
      editor: ["textarea.chatbox", "textarea", 'div[contenteditable="true"]'],
      send: ["#chatSubmitButton", 'button[id*="submit" i]', 'button[type="submit"]'],
      stop: ['button[id*="stop" i]', 'button[class*="stop" i]'],
      user: [".chatbot-user-message", '[class*="user-message" i]', '[class*="chatbot-user" i]'],
      asst: [".chatbot-ai-message", '[class*="ai-message" i]', '[class*="chatbot-ai" i]', ".outputBox"],
    },
    {
      id: "chatai", name: "ChatAI", hosts: ["chatai.org", "www.chatai.org"], pathPrefix: "/chat",
      editor: ["textarea", 'div[contenteditable="true"]'],
      send: ['button[type="submit"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label*="Stop" i]'],
    },
    {
      id: "chatbotchatapp", name: "ChatbotChatApp", hosts: ["chatbotchatapp.com", "www.chatbotchatapp.com"],
      editor: ["textarea", 'input[type="text"]', 'div[contenteditable="true"]'],
      send: ['button[type="submit"]', 'button[aria-label*="Send" i]'],
      stop: ['button[aria-label*="Stop" i]'],
    },
    {
      id: "alice", name: "Alice", hosts: ["alice.yandex.ru"],
      editor: ['textarea', 'div[contenteditable="true"][role="textbox"]', 'div[contenteditable="true"]'],
      send: ['button[aria-label*="Отправить" i]', 'button[class*="send" i]', 'button[type="submit"]'],
      stop: ['button[aria-label*="Остановить" i]', 'button[aria-label*="Stop" i]', 'button[class*="stop" i]'],
      user: ['[class*="UserMessage" i]', '[class*="user-message" i]'],
      asst: ['[class*="AliceMessage" i]', '[class*="AssistantMessage" i]', '[class*="assistant-message" i]'],
      convRe: /\/chat\/[\w-]{8,}/,
    },
    {
      id: "quillbot", name: "QuillBot", hosts: ["quillbot.com"], pathPrefix: "/ai-chat",
      editor: ['div[contenteditable="true"]', "textarea"],
      send: ['button[aria-label*="Send" i]', 'button[data-testid*="send" i]', 'button[type="submit"]'],
      stop: ['button[aria-label*="Stop" i]', 'button[data-testid*="stop" i]'],
    },
    {
      id: "giga", name: "GigaChat", hosts: ["giga.chat"],
      editor: ['textarea', '#chat-input', 'div[contenteditable="true"][role="textbox"]', 'div[contenteditable="true"]'],
      send: ['button[aria-label*="Отправить" i]', 'button[aria-label*="Send" i]', 'button[data-testid*="send" i]', 'button[type="submit"]'],
      stop: ['button[aria-label*="Остановить" i]', 'button[aria-label*="Stop" i]', 'button[data-testid*="stop" i]'],
    },
    {
      id: "nika-agent", name: "Nika Agent", hosts: ["nika-agent.ru"],
      editor: ['textarea', 'input[type="text"]', 'div[contenteditable="true"][role="textbox"]', 'div[contenteditable="true"]'],
      send: ['button[aria-label*="Отправить" i]', 'button[aria-label*="Send" i]', 'button[data-testid*="send" i]', 'button[type="submit"]'],
      stop: ['button[aria-label*="Остановить" i]', 'button[aria-label*="Stop" i]', 'button[data-testid*="stop" i]'],
    },
  ];

  PROFILES.unshift({
    id: "google-ai-mode", name: "Google AI Mode", hosts: ["www.google.com"], pathPrefix: "/search",
    queryRe: /(?:^|[?&])udm=50(?:&|$)/, vision: false,
    editor: ['textarea[aria-label*="Ask" i]', 'textarea[placeholder*="Ask" i]', '[contenteditable="true"][role="textbox"]', 'textarea', '[contenteditable="true"]'],
    send: ['button[aria-label*="Send" i]', 'button[aria-label*="Submit" i]', 'button[aria-label*="Отправ" i]', 'button[type="submit"]'],
    stop: ['button[aria-label*="Stop" i]', 'button[aria-label*="Cancel" i]'],
    user: ['[data-message-author-role="user"]', '[data-testid*="user-message" i]', '[class*="user-message" i]', '[class*="query" i]'],
    asst: ['[data-message-author-role="assistant"]', '[data-testid*="assistant" i]', '[class*="assistant-message" i]', '[class*="response-container" i]', '[class*="answer" i]'],
  });

  const host = location.hostname;
  const PROFILE =
    PROFILES.find((p) => p.hosts.includes(host) && (!p.pathPrefix || location.pathname.startsWith(p.pathPrefix)) && (!p.queryRe || p.queryRe.test(location.search))) ||
    PROFILES.find((p) => p.hosts.includes(host) && (!p.queryRe || p.queryRe.test(location.search))) ||
    { id: "generic", name: host.replace(/^www\./, ""), hosts: [host] };

  // Site list first, broad fallbacks last (duplicates dropped).
  const merge = (own, common) => [...new Set([...(own || []), ...common])];
  const C_BASE = {
    editor: merge(PROFILE.editor, COMMON.editor),
    send: merge(PROFILE.send, COMMON.send),
    stop: merge(PROFILE.stop, COMMON.stop),
    user: merge(PROFILE.user, COMMON.user),
    asst: merge(PROFILE.asst, COMMON.asst),
    codeWrap: merge(PROFILE.codeWrap, COMMON.codeWrap),
    convRe: PROFILE.convRe || COMMON.convRe,
  };
  const C = { ...C_BASE };

  // Manual CSS selectors configured in ZeroScript's AI directory are applied to
  // the active origin. Previously they were stored but never consumed here.
  function applyCustomSiteSelectors(entries) {
    const currentHost = location.hostname.toLowerCase();
    const site = (Array.isArray(entries) ? entries : [])
      .filter((item) => {
        try { return new URL(item.url).hostname.toLowerCase() === currentHost && item.selectors && typeof item.selectors === "object"; }
        catch { return false; }
      })
      .sort((a, b) => {
        const pathLength = (item) => { try { const path = new URL(item.url).pathname || "/"; return location.pathname.startsWith(path) ? path.length : -1; } catch { return -1; } };
        return pathLength(b) - pathLength(a);
      })[0];
    const selectors = site && site.selectors || {};
    const safeSelector = (value) => {
      const sel = String(value || "").trim();
      if (!sel || sel.length > 500) return "";
      try { document.querySelector(sel); return sel; } catch { return ""; }
    };
    C.editor = merge([safeSelector(selectors.input)].filter(Boolean), C_BASE.editor);
    C.send = merge([safeSelector(selectors.send)].filter(Boolean), C_BASE.send);
    C.asst = merge([safeSelector(selectors.response)].filter(Boolean), C_BASE.asst);
    diag("custom.selectors", { matched: !!site, input: !!safeSelector(selectors.input), send: !!safeSelector(selectors.send), response: !!safeSelector(selectors.response) });
  }
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get("zsCustomAISites", (r) => applyCustomSiteSelectors(r && r.zsCustomAISites));
      if (chrome.storage.onChanged) chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.zsCustomAISites) applyCustomSiteSelectors(changes.zsCustomAISites.newValue);
      });
    }
  } catch {}

  const RE = {
    contextLimit: /maximum length for this conversation|conversation.{0,20}too long|context.{0,20}(limit|length|exceeded)|message.{0,20}too long|достигли максимальной длины|слишком длинн|превышен.{0,20}лимит/i,
    tooLong: /maximum length|conversation .{0,20}too long|message.{0,20}too long|context.{0,20}(limit|exceeded)|слишком длинн/i,
    busy: /something went wrong|try again later|too many requests|network error|rate limit|overloaded|что-то пошло не так|повторите попытку|слишком много запросов/i,
  };

  const timings = {
    GEN_IDLE_MS: 2000,
    REASON_IDLE_MS: 15000,
    WARMUP_MS: 90000,
    REASON_NOREPLY_MS: 180000,
    STABLE_MS: 10000,
    RESPONSE_TIMEOUT_MS: 600000,
  };

  // ── Selector helpers ────────────────────────────────────────────────────
  const visible = (e) => !!e && (e.offsetParent !== null || getComputedStyle(e).position === "fixed");
  const safeAll = (sel) => { try { return [...document.querySelectorAll(sel)]; } catch { return []; } };
  const joined = (list) => list.join(", ");
  const own = (e) => !e.closest("#zs-root");

  function pickEl(list, needVisible) {
    for (const sel of list) {
      for (const e of safeAll(sel)) {
        if (!own(e)) continue;
        if (needVisible && !visible(e)) continue;
        return e;
      }
    }
    return null;
  }

  // ── Structural fallback (sent-text anchored) ─────────────────────────────
  const _sent = []; // normalised snippets of what ZeroScript typed
  const snip = (t) => String(t || "").replace(/\s+/g, "").slice(0, 28);
  let _listParent = null;

  function findListParent() {
    if (_listParent && _listParent.isConnected) return _listParent;
    _listParent = null;
    if (!_sent.length) return null;
    const ed = getEditor();
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let n;
    while ((n = w.nextNode())) {
      const el = n.parentElement;
      if (!el || !own(el) || (ed && ed.contains(el))) continue;
      if (/^(SCRIPT|STYLE|TEXTAREA)$/.test(el.tagName)) continue;
      const t = (n.nodeValue || "").replace(/\s+/g, "");
      if (t.length < 8 || !_sent.some((s) => t.includes(s.slice(0, 20)))) continue;
      let cur = el;
      while (cur.parentElement && cur.parentElement !== document.body) {
        const par = cur.parentElement;
        if (ed && par.contains(ed)) break;
        if (par.children.length >= 2) { _listParent = par; return par; }
        cur = par;
      }
    }
    return null;
  }
  const structuralItems = () => {
    const p = findListParent();
    return p ? [...p.children].filter((c) => own(c) && (c.textContent || "").trim().length > 0) : [];
  };
  const hasUserSel = () => safeAll(joined(C.user)).some(own);
  const hasAsstSel = () => safeAll(joined(C.asst)).some(own);
  const useStructural = () => (!hasUserSel() || !hasAsstSel()) && _sent.length > 0;
  const looksSent = (item) => {
    const t = (item.textContent || "").replace(/\s+/g, "");
    return _sent.some((s) => t.includes(s));
  };

  // ── Turn lists ──────────────────────────────────────────────────────────
  const userSel = () => joined(C.user);
  const asstSel = () => joined(C.asst);

  // Selectors can overlap (a broad class matching both a bubble and a child); keep
  // only outermost elements so each turn is counted once.
  const outermost = (els) => els.filter((e) => !els.some((o) => o !== e && o.contains(e)));

  function userItems() {
    if (useStructural()) return structuralItems().filter(looksSent);
    return outermost(safeAll(userSel()).filter(own));
  }
  function assistantItems() {
    if (useStructural()) return structuralItems().filter((i) => !looksSent(i));
    const users = safeAll(userSel());
    return outermost(safeAll(asstSel()).filter((e) => own(e) && !users.some((u) => u === e || u.contains(e) || e.contains(u))));
  }
  const allItems = () => {
    const s = new Set([...userItems(), ...assistantItems()]);
    return [...s].sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  };
  const isUserItem = (item) => !!item && userItems().includes(item);
  const isAssistantItem = (item) => !!item && assistantItems().includes(item);
  const assistantCount = () => assistantItems().length;
  const userCount = () => userItems().length;
  const lastAssistant = () => { const it = assistantItems(); return it.length ? it[it.length - 1] : null; };
  const chatIsEmpty = () => allItems().length === 0;

  // Stable id for the last assistant turn (survives re-renders when the site gives one).
  const lastAssistantId = () => {
    const it = lastAssistant();
    if (!it) return null;
    const id = it.getAttribute("data-message-id") || it.id || it.getAttribute("data-id") || it.getAttribute("data-testid-id");
    return id || String(assistantCount());
  };

  // ── Text extraction ─────────────────────────────────────────────────────
  const BLOCK = new Set(["P", "DIV", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "PRE", "BR", "TR"]);
  function textWithout(root, excludeSel) {
    if (!root) return "";
    const skip = ".zs-chip, button, style, script" + (excludeSel ? ", " + excludeSel : "");
    let t = "";
    const walk = (n) => {
      if (n.nodeType === 3) { t += n.nodeValue; return; }
      if (n.nodeType !== 1) return;
      if (n.matches && n.matches(skip)) return;
      for (const c of n.childNodes) walk(c);
      if (BLOCK.has(n.tagName) && t && !t.endsWith("\n")) t += "\n";
    };
    walk(root);
    return t;
  }
  const itemText = (item) => textWithout(item);
  const classifyText = (item, excludeSel) => textWithout(item, excludeSel);

  // ── Editor ──────────────────────────────────────────────────────────────
  const isTextarea = (e) => !!e && (e.tagName === "TEXTAREA" || e.tagName === "INPUT");
  function getEditor() {
    for (const sel of C.editor) {
      const cands = safeAll(sel).filter((e) => own(e) && visible(e) && !e.disabled && e.type !== "hidden" && e.type !== "file");
      if (cands.length) return cands[cands.length - 1]; // composer sits below the history
    }
    return null;
  }
  const editorText = () => {
    const e = getEditor();
    if (!e) return "";
    return isTextarea(e) ? e.value : e.textContent || "";
  };
  const norm = (s) => String(s || "").replace(/\s+/g, "");
  const isFreshChat = () => chatIsEmpty() && !!getEditor();
  const composerFrame = () => {
    const ed = getEditor();
    if (!ed) return null;
    let n = ed.closest("form");
    if (n) return n;
    // No form: climb until the box also holds a button (the send/attach row).
    n = ed.parentElement;
    for (let i = 0; i < 6 && n && n !== document.body; i++, n = n.parentElement) {
      if (n.querySelector("button")) return n;
    }
    return ed.parentElement;
  };
  const barAnchor = () => composerFrame();

  let _locked = false;
  function setInputLock(on) {
    _locked = on;
    const ed = getEditor();
    if (!ed) return;
    if (isTextarea(ed)) { if (on) ed.setAttribute("readonly", ""); else ed.removeAttribute("readonly"); return; }
    ed.setAttribute("contenteditable", on ? "false" : "true");
  }

  // ── Buttons ─────────────────────────────────────────────────────────────
  const NOT_SEND = /attach|upload|file|mic|voice|record|dictat|микроф|прикреп|файл|голос|search|menu|меню|model|модел|new chat|новый/i;
  const labelOf = (b) => `${b.getAttribute("aria-label") || ""} ${b.getAttribute("title") || ""} ${b.getAttribute("data-testid") || ""} ${b.className && b.className.baseVal === undefined ? b.className : ""}`;

  function sendButton() {
    const f = composerFrame() || document;
    for (const sel of C.send) {
      for (const b of f.querySelectorAll(sel)) if (visible(b) && own(b) && !NOT_SEND.test(labelOf(b))) return b;
    }
    // Heuristic: the last enabled, text-less/icon button after the editor in the composer.
    const ed = getEditor();
    if (ed) {
      const btns = [...f.querySelectorAll("button")].filter((b) => visible(b) && own(b) && !b.disabled && !NOT_SEND.test(labelOf(b)) && !(ed.contains(b)) &&
        (ed.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING));
      if (btns.length) return btns[btns.length - 1];
    }
    return null;
  }
  function stopButton() {
    const f = composerFrame();
    for (const sel of C.stop) {
      const b = (f && f.querySelector(sel)) || document.querySelector(sel);
      if (b && visible(b) && own(b)) return b;
    }
    return null;
  }

  // ── Generation detection ────────────────────────────────────────────────
  const streamText = (item) => (item ? textWithout(item, ".zs-chip") : "");
  const streamLen = (item) => streamText(item === undefined ? lastAssistant() : item).length;

  let _max = -1, _at = 0, _item = null;
  function sample() {
    const item = lastAssistant();
    const len = streamText(item).length;
    const now = Date.now();
    if (item !== _item || len < _max - 400) { _item = item; _max = len; _at = now; return; }
    if (len > _max) { _max = len; _at = now; }
  }
  function genActive() {
    sample();
    if (stopButton()) return true;
    return _max > 1 && Date.now() - _at < timings.GEN_IDLE_MS;
  }
  const isGenerating = genActive;
  const isBusyNow = genActive;
  const isHardGenerating = () => !!stopButton();

  const turnHalted = () => false;
  const findContinueBtn = () => null;
  const clickContinueBtn = () => false;

  function snapshot() {
    try { const it = lastAssistant(); return { th: 0, rp: it ? streamText(it).length : 0 }; } catch { return {}; }
  }
  function readAssistant() {
    const item = lastAssistant();
    if (!item) return { present: false, reply: "", thinking: "", item: null };
    return { present: true, reply: textWithout(item, ".zs-chip").trim(), thinking: "", item };
  }
  async function waitFor(pred, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) { if (pred()) return true; await sleep(120); }
    return false;
  }

  // ── Sending ─────────────────────────────────────────────────────────────
  function setEditorText(ed, text) {
    if (isTextarea(ed)) {
      const proto = ed.tagName === "INPUT" ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value");
      ed.focus();
      if (setter && setter.set) setter.set.call(ed, text); else ed.value = text;
      ed.dispatchEvent(new Event("input", { bubbles: true }));
      ed.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    ed.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(ed);
    sel.removeAllRanges();
    sel.addRange(range);
    const lines = String(text).split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertLineBreak");
    }
    // Some editors ignore execCommand: fall back to a plain text/paste insert.
    if (norm(ed.textContent) !== norm(text)) {
      try {
        const dt = new DataTransfer();
        dt.setData("text/plain", text);
        range.selectNodeContents(ed);
        sel.removeAllRanges(); sel.addRange(range);
        ed.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
      } catch {}
    }
  }

  const hasPendingAttachment = () => {
    const f = composerFrame();
    return !!(f && f.querySelector('img[src^="blob:"], img[src^="data:"], [data-testid*="attachment" i], [class*="attachment" i], button[aria-label*="Remove" i], button[aria-label*="Удалить" i]'));
  };

  async function typeAndSend(text, images) {
    const ed = getEditor();
    if (!ed) throw new Error(`${PROFILE.name} input box not found`);
    const relock = _locked;
    if (relock) { if (isTextarea(ed)) ed.removeAttribute("readonly"); else ed.setAttribute("contenteditable", "true"); }
    try {
      const k = snip(text);
      if (k && !_sent.includes(k)) _sent.push(k);
      if (norm(editorText()) !== norm(text)) setEditorText(ed, text);
      const withImg = !!(images && images.length);
      if (withImg && !hasPendingAttachment()) {
        if (!PROFILE.vision) diag("attach.skipped", { note: `${PROFILE.name}: image upload not supported` });
        else { try { diag("attach.beforeCall", { count: images.length }); await attachImages(images); } catch (e) { diag("attach.threw", { msg: String((e && e.message) || e) }); } }
      }
      await waitFor(() => { const b = sendButton(); return !!b && !b.disabled && b.getAttribute("aria-disabled") !== "true"; }, withImg && PROFILE.vision ? 40000 : 5000);
      const btn = sendButton();
      diag("send.click", { found: !!btn, site: PROFILE.id, pending: hasPendingAttachment() });
      if (btn && !btn.disabled) { btn.click(); return; }
      const o = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
      ed.dispatchEvent(new KeyboardEvent("keydown", o));
      ed.dispatchEvent(new KeyboardEvent("keypress", o));
      ed.dispatchEvent(new KeyboardEvent("keyup", o));
    } finally {
      if (relock) { const e2 = getEditor(); if (e2) { if (isTextarea(e2)) e2.setAttribute("readonly", ""); else e2.setAttribute("contenteditable", "false"); } }
    }
  }

  function stopGeneration() { const b = stopButton(); if (b) try { b.click(); } catch {} }
  function enforceComposer() { return { ready: !!getEditor() }; }
  async function ensureComposerReady(reason) {
    diag("mode_ready", { reason, provider: PROFILE.id });
    return { ready: !!getEditor() };
  }

  // ── Errors / limits ─────────────────────────────────────────────────────
  function scanError() {
    try {
      for (const el of document.querySelectorAll('[role="alert"],[class*="toast" i],[class*="error" i],[class*="snackbar" i]')) {
        if (!visible(el) || !own(el)) continue;
        if (allItems().some((i) => i.contains(el))) continue;
        const t = (el.innerText || "").trim();
        if (t.length > 8 && t.length < 600 && RE.contextLimit.test(t)) return t.slice(0, 240);
      }
    } catch {}
    if (!getEditor()) return "The input box disappeared (session ended?).";
    return null;
  }
  const isTooLongMsg = (t) => RE.tooLong.test(t);
  const isBusyMsg = (t) => RE.busy.test(t);

  // ── Images (paste onto the composer; only on profiles flagged vision) ─────
  function fileFromImage(img, i) {
    const mime = img.mimeType || "image/jpeg";
    const bin = atob(img.data);
    const arr = new Uint8Array(bin.length);
    for (let j = 0; j < bin.length; j++) arr[j] = bin.charCodeAt(j);
    return new File([arr], `zeroscript_${Date.now()}_${i}.${mime.includes("png") ? "png" : "jpg"}`, { type: mime });
  }
  async function attachImages(images) {
    const ed = getEditor();
    if (!PROFILE.vision || !ed || !images || !images.length) return false;
    const dt = new DataTransfer();
    images.forEach((img, i) => { try { dt.items.add(fileFromImage(img, i)); } catch {} });
    if (!dt.items.length) return false;
    ed.focus();
    ed.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    const ok = await waitFor(hasPendingAttachment, 15000);
    diag("attach.previewOk", { ok });
    return ok;
  }
  function clearAttachments() {
    try {
      const f = composerFrame();
      if (f) f.querySelectorAll('button[aria-label*="Remove" i], button[aria-label*="Удалить" i]').forEach((b) => { try { b.click(); } catch {} });
    } catch {}
  }

  // A real conversation URL (when the site has one) else "" while the chat is empty;
  // sites that never change the URL fall back to path+search+hash once non-empty.
  const conversationKey = () => {
    if (chatIsEmpty()) return "";
    return C.convRe.test(location.pathname) ? location.pathname : location.pathname + location.search + location.hash;
  };

  // ── Send interception ───────────────────────────────────────────────────
  function installSendHooks(handlers) {
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      const ed = getEditor();
      if (!ed || !ed.contains(e.target)) return;
      if (editorText().trim() === "") return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);

    document.addEventListener("click", (e) => {
      if (!getEditor() || !e.target || !e.target.closest) return;
      const st = stopButton();
      if (st && (st === e.target || st.contains(e.target))) { handlers.onNativeStop(); return; }
      const sb = sendButton();
      if (!sb || !(sb === e.target || sb.contains(e.target)) || sb.disabled) return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);
  }

  // ── Tool-block camouflage ───────────────────────────────────────────────
  const CMD_SHAPE = /"(?:command|tool)"\s*:\s*"|###\s*lua|###mcp_tool###/i;
  function findToolBlockSpot(item /*, chip */) {
    if (!item) return null;
    let hidAny = null;
    item.querySelectorAll("pre").forEach((pre) => {
      if (pre.closest(".zs-chip")) return;
      if (!CMD_SHAPE.test(pre.textContent || "")) return;
      let wrap = pre;
      for (const sel of C.codeWrap) { try { const w = pre.closest(sel); if (w && item.contains(w)) { wrap = w; break; } } catch {} }
      wrap.classList.add("zs-tool-hide");
      item.classList.add("zs-cmd-mask-pre");
      hidAny = hidAny || { parent: wrap.parentElement, ref: wrap };
    });
    // Sites that render commands as plain paragraphs instead of code blocks.
    [...item.querySelectorAll("p, div")].forEach((el) => {
      if (el.closest(".zs-chip") || el.closest(".zs-tool-hide") || el.querySelector("pre, div, p")) return;
      const t = el.textContent || "";
      if (t.length < 600 && CMD_SHAPE.test(t)) {
        el.classList.add("zs-tool-hide");
        hidAny = hidAny || { parent: el.parentElement, ref: el };
      }
    });
    return hidAny;
  }

  return {
    id: PROFILE.id,
    displayName: PROFILE.name,
    supportsVision: !!PROFILE.vision,
    timings,
    chipAtItemLevel: true,
    reliableCounts: false,
    init({ diag: d } = {}) { if (d) diag = d; },
    allItems, isUserItem, isAssistantItem, itemText, classifyText,
    assistantCount, userCount, lastAssistant, lastAssistantId, readAssistant,
    streamLen, snapshot,
    getEditor, editorText, chatIsEmpty, isFreshChat, composerFrame, barAnchor,
    setInputLock, typeAndSend, stopGeneration,
    isGenerating, isBusyNow, isHardGenerating,
    enforceComposer, ensureComposerReady,
    turnHalted, findContinueBtn, clickContinueBtn,
    scanError, isTooLongMsg, isBusyMsg,
    attachImages, clearAttachments, conversationKey,
    installSendHooks, findToolBlockSpot,
  };
})();
