// SPDX-License-Identifier: GPL-3.0-or-later
// providers/tokenwave.js - the TokenWave chat (tokenwave.ru/chat) provider.
// Same ZSProvider interface as the other providers.
//
// !! CALIBRATION NOTE !! The page source was not available in readable form when
// this file was written (the DOM is built by the site's JS), so every selector is a
// LIST OF CANDIDATES in the C table below; the first one that matches the live page
// wins. If the extension does not see messages / the send button, run the probe
// snippet from the instructions in DevTools on tokenwave.ru/chat and put the real
// selectors at the FRONT of the matching lists - nothing else needs to change.
// eslint-disable-next-line no-unused-vars
const ZSProvider = (() => {
  "use strict";
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let diag = () => {};

  const C = {
    editor: ['textarea[placeholder*="Сообщение"]', 'textarea[placeholder*="essage"]', "#msg", "#chat-input", "#message", "textarea"],
    send: ['button[type="submit"]', "#send", "#send-btn", 'button[aria-label*="Отправ"]', 'button[aria-label*="Send"]', 'button[title*="Отправ"]'],
    stop: ['button[aria-label*="Стоп"]', 'button[aria-label*="Останов"]', 'button[aria-label*="Stop"]', 'button[title*="Стоп"]', "#stop", ".stop-btn"],
    user: ['[data-role="user"]', ".msg.user", ".msg-user", ".message-user", ".message.user", ".user-message", ".chat-msg.user", ".bubble.user", ".msg--user"],
    assistant: ['[data-role="assistant"]', ".msg.assistant", ".msg-assistant", ".message-assistant", ".message.assistant", ".assistant-message", ".chat-msg.assistant", ".msg.bot", ".bubble.assistant", ".msg--assistant", ".msg.ai"],
    composer: ["form#chat-form", "form.composer", "form.chat-form", ".composer", ".chat-input", "form"],
    codeWrap: [".code-block", ".codeblock", ".code-wrap", "pre"],
  };

  // First candidate that currently matches something visible/present (not in our UI).
  const firstMatch = (list) => {
    for (const sel of list) {
      try {
        for (const el of document.querySelectorAll(sel)) if (!el.closest("#zs-root")) return sel;
      } catch {}
    }
    return null;
  };
  const pickEl = (list, vis) => {
    for (const sel of list) {
      try {
        for (const el of document.querySelectorAll(sel)) {
          if (el.closest("#zs-root")) continue;
          if (!vis || el.offsetParent !== null) return el;
        }
      } catch {}
    }
    return null;
  };
  const userSel = () => firstMatch(C.user) || C.user[0];
  const asstSel = () => firstMatch(C.assistant) || C.assistant[0];
  const anySel = () => `${userSel()}, ${asstSel()}`;

  const RE = {
    contextLimit: /context.{0,20}(limit|exceeded)|слишком длинн|превышен.{0,20}контекст|недостаточно (средств|токенов)|баланс/i,
    tooLong: /слишком длинн|conversation .{0,20}too long/i,
    busy: /something went wrong|try again later|ошибка|повторите/i,
  };

  const timings = {
    GEN_IDLE_MS: 2500,
    REASON_IDLE_MS: 15000,
    WARMUP_MS: 90000,
    REASON_NOREPLY_MS: 180000,
    STABLE_MS: 10000,
    RESPONSE_TIMEOUT_MS: 600000,
  };

  const isUserItem = (item) => !!item && item.matches && item.matches(userSel());
  const isAssistantItem = (item) => !!item && item.matches && item.matches(asstSel());

  const BLOCK = new Set(["P", "DIV", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "PRE", "BR", "TR"]);
  function textWithout(root, excludeSel) {
    if (!root) return "";
    const skip = ".zs-chip, button" + (excludeSel ? ", " + excludeSel : "");
    let t = "";
    const walk = (n) => {
      if (n.nodeType === 3) { t += n.nodeValue; return; }
      if (n.nodeType !== 1) return;
      if (n.matches && n.matches(skip)) return;
      for (const c of n.childNodes) walk(c);
      if (BLOCK.has(n.tagName) && t && !t.endsWith("\n")) t += "\n";
    };
    walk(root);
    return t;
  }
  const itemText = (item) => textWithout(item);
  const classifyText = (item, excludeSel) => textWithout(item, excludeSel);

  const allItems = () => { try { return [...document.querySelectorAll(anySel())].filter((e) => !e.closest("#zs-root")); } catch { return []; } };
  const assistantItems = () => { try { return [...document.querySelectorAll(asstSel())].filter((e) => !e.closest("#zs-root")); } catch { return []; } };
  const assistantCount = () => assistantItems().length;
  const userCount = () => { try { return [...document.querySelectorAll(userSel())].filter((e) => !e.closest("#zs-root")).length; } catch { return 0; } };
  const getEditor = () => pickEl(C.editor, false);
  const isTextarea = (e) => !!e && e.tagName === "TEXTAREA";
  const editorText = () => {
    const e = getEditor();
    if (!e) return "";
    return isTextarea(e) ? e.value : e.textContent || "";
  };
  const norm = (s) => String(s || "").replace(/\s+/g, "");
  const lastAssistant = () => { const it = assistantItems(); return it.length ? it[it.length - 1] : null; };
  const chatIsEmpty = () => allItems().length === 0;
  const isFreshChat = () => chatIsEmpty() && !!getEditor();
  const composerFrame = () => {
    const ed = getEditor();
    return (ed && (ed.closest("form") || ed.parentElement)) || pickEl(C.composer, true);
  };
  const barAnchor = () => composerFrame();

  let _locked = false;
  function setInputLock(on) {
    _locked = on;
    const ed = getEditor();
    if (!ed) return;
    if (isTextarea(ed)) { if (on) ed.setAttribute("readonly", ""); else ed.removeAttribute("readonly"); }
    else ed.setAttribute("contenteditable", on ? "false" : "true");
  }

  const sendButton = () => {
    const f = composerFrame() || document;
    for (const sel of C.send) { const b = f.querySelector(sel); if (b && b.offsetParent !== null && !b.closest("#zs-root")) return b; }
    return null;
  };
  const stopButton = () => {
    const f = composerFrame() || document;
    for (const sel of C.stop) { const b = f.querySelector(sel) || document.querySelector(sel); if (b && b.offsetParent !== null && !b.closest("#zs-root")) return b; }
    return null;
  };

  const streamText = (item) => (item ? textWithout(item, ".zs-chip") : "");
  const streamLen = (item) => streamText(item === undefined ? lastAssistant() : item).length;
  let _max = -1, _at = 0, _item = null;
  function sample() {
    const item = lastAssistant();
    const len = streamText(item).length;
    const now = Date.now();
    if (item !== _item || len < _max - 400) { _item = item; _max = len; _at = now; return; }
    if (len > _max) { _max = len; _at = now; }
  }
  // No known stop button => detect generation by text growth alone.
  function genActive() {
    sample();
    if (stopButton()) return true;
    return _max > 1 && Date.now() - _at < timings.GEN_IDLE_MS;
  }
  const isGenerating = genActive;
  const isBusyNow = genActive;
  const isHardGenerating = () => !!stopButton();

  const turnHalted = () => false;
  const findContinueBtn = () => null;
  const clickContinueBtn = () => false;

  function snapshot() {
    try { const it = lastAssistant(); return { th: 0, rp: it ? streamText(it).length : 0 }; } catch { return {}; }
  }
  function readAssistant() {
    const item = lastAssistant();
    if (!item) return { present: false, reply: "", thinking: "", item: null };
    return { present: true, reply: textWithout(item, ".zs-chip").trim(), thinking: "", item };
  }
  async function waitFor(pred, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) { if (pred()) return true; await sleep(120); }
    return false;
  }

  function setEditorText(ed, text) {
    if (isTextarea(ed)) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value");
      if (setter && setter.set) setter.set.call(ed, text); else ed.value = text;
      ed.dispatchEvent(new Event("input", { bubbles: true }));
      ed.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    ed.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(ed);
    sel.removeAllRanges();
    sel.addRange(range);
    const lines = String(text).split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertLineBreak");
    }
  }

  async function typeAndSend(text, images) {
    const ed = getEditor();
    if (!ed) throw new Error("TokenWave input box not found");
    const relock = _locked;
    if (relock) { if (isTextarea(ed)) ed.removeAttribute("readonly"); else ed.setAttribute("contenteditable", "true"); }
    try {
      if (norm(editorText()) !== norm(text)) setEditorText(ed, text);
      if (images && images.length) diag("attach.skipped", { note: "tokenwave image upload not implemented" });
      await waitFor(() => { const b = sendButton(); return !!b && !b.disabled; }, 4000);
      const btn = sendButton();
      diag("send.click", { found: !!btn });
      if (btn && !btn.disabled) { btn.click(); return; }
      const o = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
      ed.dispatchEvent(new KeyboardEvent("keydown", o));
      ed.dispatchEvent(new KeyboardEvent("keyup", o));
    } finally {
      if (relock) { const e2 = getEditor(); if (e2) { if (isTextarea(e2)) e2.setAttribute("readonly", ""); else e2.setAttribute("contenteditable", "false"); } }
    }
  }

  function stopGeneration() { const b = stopButton(); if (b) try { b.click(); } catch {} }
  function enforceComposer() { return { ready: !!getEditor() }; }
  async function ensureComposerReady(reason) {
    diag("mode_ready", { reason, provider: "tokenwave" });
    return { ready: !!getEditor() };
  }

  function scanError() {
    try {
      for (const el of document.querySelectorAll('[role="alert"],[class*="toast"],[class*="error"]')) {
        if (el.offsetParent === null || el.closest("#zs-root")) continue;
        try { if (el.closest(anySel())) continue; } catch {}
        const t = (el.innerText || "").trim();
        if (t.length > 8 && t.length < 600 && RE.contextLimit.test(t)) return t.slice(0, 240);
      }
    } catch {}
    if (!getEditor()) return "The input box disappeared (session ended?).";
    return null;
  }
  const isTooLongMsg = (t) => RE.tooLong.test(t);
  const isBusyMsg = (t) => RE.busy.test(t);

  // Image upload is not implemented for TokenWave: screen_capture stays disabled.
  async function attachImages() { return false; }
  function clearAttachments() {}

  // Chats are stored in the browser; the URL may not change per chat, so an empty
  // chat is always "" (transient) and a non-empty one is keyed by URL.
  const conversationKey = () => (chatIsEmpty() ? "" : location.pathname + location.search + location.hash);

  function installSendHooks(handlers) {
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      const ed = getEditor();
      if (!ed || !ed.contains(e.target)) return;
      if (editorText().trim() === "") return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);

    document.addEventListener("click", (e) => {
      if (!getEditor() || !e.target || !e.target.closest) return;
      const st = stopButton();
      if (st && (st === e.target || st.contains(e.target))) { handlers.onNativeStop(); return; }
      const sb = sendButton();
      if (!sb || !(sb === e.target || sb.contains(e.target)) || sb.disabled) return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);
  }

  const CMD_SHAPE = /"(?:command|tool)"\s*:\s*"|###\s*lua|###mcp_tool###/i;
  function findToolBlockSpot(item /*, chip */) {
    if (!item) return null;
    let hidAny = null;
    item.querySelectorAll("pre").forEach((pre) => {
      if (pre.closest(".zs-chip")) return;
      if (!CMD_SHAPE.test(pre.textContent || "")) return;
      let wrap = pre;
      for (const sel of C.codeWrap) { const w = pre.closest(sel); if (w && item.contains(w)) { wrap = w; break; } }
      wrap.classList.add("zs-tool-hide");
      item.classList.add("zs-cmd-mask-pre");
      hidAny = hidAny || { parent: wrap.parentElement, ref: wrap };
    });
    [...item.querySelectorAll("p, div")].forEach((el) => {
      if (el.closest(".zs-chip") || el.closest(".zs-tool-hide") || el.querySelector("pre, div, p")) return;
      const t = el.textContent || "";
      if (t.length < 600 && CMD_SHAPE.test(t)) {
        el.classList.add("zs-tool-hide");
        hidAny = hidAny || { parent: el.parentElement, ref: el };
      }
    });
    return hidAny;
  }

  return {
    id: "tokenwave",
    displayName: "TokenWave",
    supportsVision: false,
    timings,
    chipAtItemLevel: true,
    reliableCounts: false,
    init({ diag: d } = {}) { if (d) diag = d; },
    allItems, isUserItem, isAssistantItem, itemText, classifyText,
    assistantCount, userCount, lastAssistant, readAssistant,
    streamLen, snapshot,
    getEditor, editorText, chatIsEmpty, isFreshChat, composerFrame, barAnchor,
    setInputLock, typeAndSend, stopGeneration,
    isGenerating, isBusyNow, isHardGenerating,
    enforceComposer, ensureComposerReady,
    turnHalted, findContinueBtn, clickContinueBtn,
    scanError, isTooLongMsg, isBusyMsg,
    attachImages, clearAttachments, conversationKey,
    installSendHooks, findToolBlockSpot,
  };
})();
