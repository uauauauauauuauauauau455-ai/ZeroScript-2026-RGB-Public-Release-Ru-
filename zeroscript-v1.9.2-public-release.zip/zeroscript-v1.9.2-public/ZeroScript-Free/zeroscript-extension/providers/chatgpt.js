// SPDX-License-Identifier: GPL-3.0-or-later
// providers/chatgpt.js - the ChatGPT (chatgpt.com) provider.
// Same ZSProvider interface as providers/gemini.js; core/main.js stays untouched.
// To DISABLE ChatGPT support remove this file from manifest.json (and its URLs
// from background.js PROVIDER_URLS and AI_SITES in core/main.js).
//
// ChatGPT DOM notes (selectors based on the public chatgpt.com markup; if the site
// changes its markup, only the S table below needs adjusting):
//  - Each message is an element with data-message-author-role="user"|"assistant"
//    and a stable data-message-id (used as the turn identity).
//  - Reply markdown lives in `.markdown` inside the assistant message.
//  - Composer: ProseMirror contenteditable `#prompt-textarea` inside
//    form[data-type="unified-composer"]. Text is injected with execCommand.
//  - Buttons are identified by data-testid: send-button / stop-button.
//  - Conversation URL is /c/<id>; a fresh chat is "/".
// eslint-disable-next-line no-unused-vars
const ZSProvider = (() => {
  "use strict";
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let diag = () => {}; // injected by core via init()

  const S = {
    userItem: '[data-message-author-role="user"]',
    assistantItem: '[data-message-author-role="assistant"]',
    anyItem: '[data-message-author-role="user"], [data-message-author-role="assistant"]',
    reply: ".markdown",
    editor: "#prompt-textarea",
    composer: 'form[data-type="unified-composer"]',
    sendBtn: '[data-testid="send-button"]',
    stopBtn: '[data-testid="stop-button"], button[aria-label="Stop streaming"]',
    codeWrap: "div.contain-inline-size",
    errorSurfaces: '[role="alert"],[class*="toast"],[class*="error"]',
  };

  const RE = {
    contextLimit: /maximum length for this conversation|conversation.{0,20}too long|context.{0,20}(limit|exceeded)|достигли максимальной длины/i,
    tooLong: /maximum length for this conversation|conversation .{0,20}too long/i,
    busy: /something went wrong|try again later|too many requests|network error/i,
  };

  const timings = {
    GEN_IDLE_MS: 1500,
    REASON_IDLE_MS: 15000,
    WARMUP_MS: 60000,
    REASON_NOREPLY_MS: 180000, // reasoning models can think for minutes
    STABLE_MS: 9000,
    RESPONSE_TIMEOUT_MS: 600000,
  };

  // ── Turn classification ─────────────────────────────────────────────────
  const isUserItem = (item) => !!item && item.matches && item.matches(S.userItem);
  const isAssistantItem = (item) => !!item && item.matches && item.matches(S.assistantItem);

  const BLOCK = new Set(["P", "DIV", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "PRE", "BR", "TR"]);
  function textWithout(root, excludeSel) {
    if (!root) return "";
    const skip = ".zs-chip, button" + (excludeSel ? ", " + excludeSel : "");
    let t = "";
    const walk = (n) => {
      if (n.nodeType === 3) { t += n.nodeValue; return; }
      if (n.nodeType !== 1) return;
      if (n.matches && n.matches(skip)) return;
      for (const c of n.childNodes) walk(c);
      if (BLOCK.has(n.tagName) && t && !t.endsWith("\n")) t += "\n";
    };
    walk(root);
    return t;
  }
  const bodyOf = (item) => (isAssistantItem(item) && item.querySelector(S.reply)) || item;
  const itemText = (item) => textWithout(item ? bodyOf(item) : null);
  const classifyText = (item, excludeSel) => textWithout(item ? bodyOf(item) : null, excludeSel);

  // ── DOM primitives ──────────────────────────────────────────────────────
  const allItems = () => [...document.querySelectorAll(S.anyItem)];
  const assistantItems = () => [...document.querySelectorAll(S.assistantItem)];
  const assistantCount = () => assistantItems().length;
  const userCount = () => document.querySelectorAll(S.userItem).length;
  const getEditor = () => {
    for (const e of document.querySelectorAll(S.editor)) if (!e.closest("#zs-root")) return e;
    return null;
  };
  const isTextarea = (e) => !!e && e.tagName === "TEXTAREA";
  const editorText = () => {
    const e = getEditor();
    if (!e) return "";
    return isTextarea(e) ? e.value : e.textContent || "";
  };
  const norm = (s) => String(s || "").replace(/\s+/g, "");
  const lastAssistant = () => {
    const it = assistantItems();
    return it.length ? it[it.length - 1] : null;
  };
  // Stable per-turn identity (survives re-renders): data-message-id.
  const lastAssistantId = () => {
    const it = lastAssistant();
    return it ? it.getAttribute("data-message-id") : null;
  };
  const chatIsEmpty = () => allItems().length === 0;
  const isFreshChat = () => chatIsEmpty() && !!getEditor();
  const composerFrame = () => {
    const ed = getEditor();
    return document.querySelector(S.composer) || (ed ? ed.closest("form") : null);
  };
  // The status bar hugs the composer's top edge (position:fixed) instead of being
  // inserted into React's subtree - same approach as Kimi/GLM.
  const barAnchor = () => composerFrame();

  // ── Input lock ──────────────────────────────────────────────────────────
  let _locked = false;
  function setInputLock(on) {
    _locked = on;
    const ed = getEditor();
    if (!ed) return;
    if (isTextarea(ed)) { if (on) ed.setAttribute("readonly", ""); else ed.removeAttribute("readonly"); return; }
    ed.setAttribute("contenteditable", on ? "false" : "true");
  }

  // ── Buttons ─────────────────────────────────────────────────────────────
  const visible = (b) => !!b && b.offsetParent !== null;
  const sendButton = () => {
    const f = composerFrame();
    const b = (f && f.querySelector(S.sendBtn)) || document.querySelector(S.sendBtn);
    return visible(b) ? b : null;
  };
  const stopButton = () => {
    const f = composerFrame();
    const b = (f && f.querySelector(S.stopBtn)) || document.querySelector(S.stopBtn);
    return visible(b) ? b : null;
  };

  // ── Generation detection ────────────────────────────────────────────────
  const streamText = (item) => (item ? textWithout(bodyOf(item), ".zs-chip") : "");
  const streamLen = (item) => streamText(item === undefined ? lastAssistant() : item).length;

  let _streamMax = -1, _streamAt = 0, _streamItem = null;
  function sampleStream() {
    const item = lastAssistant();
    const len = streamText(item).length;
    const now = Date.now();
    if (item !== _streamItem || len < _streamMax - 400) { _streamItem = item; _streamMax = len; _streamAt = now; return; }
    if (len > _streamMax) { _streamMax = len; _streamAt = now; }
  }
  const grewWithin = (ms) => _streamMax > 1 && Date.now() - _streamAt < ms;

  // Reasoning models show a stop button while "thinking" with no text growth at
  // all, so the stop button is trusted as-is (no wedge guard like Gemini).
  function genActive() {
    sampleStream();
    if (stopButton()) return true;
    return grewWithin(timings.GEN_IDLE_MS);
  }
  const isGenerating = genActive;
  const isBusyNow = genActive;
  const isHardGenerating = () => !!stopButton();

  const turnHalted = () => false;
  const findContinueBtn = () => null;
  const clickContinueBtn = () => false;

  function snapshot() {
    try {
      const it = lastAssistant();
      return { th: 0, rp: it ? streamText(it).length : 0 };
    } catch { return {}; }
  }

  function readAssistant() {
    const item = lastAssistant();
    if (!item) return { present: false, reply: "", thinking: "", item: null };
    return { present: true, reply: textWithout(bodyOf(item), ".zs-chip").trim(), thinking: "", item };
  }

  async function waitFor(pred, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      if (pred()) return true;
      await sleep(120);
    }
    return false;
  }

  // ── Sending ─────────────────────────────────────────────────────────────
  function setEditorText(ed, text) {
    if (isTextarea(ed)) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value");
      if (setter && setter.set) setter.set.call(ed, text); else ed.value = text;
      ed.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    ed.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(ed);
    sel.removeAllRanges();
    sel.addRange(range);
    // Line by line + soft break: one big multi-line insertText is slow in rich editors.
    const lines = String(text).split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertLineBreak");
    }
  }

  const hasPendingAttachment = () => {
    const f = composerFrame();
    return !!(f && f.querySelector('img[src^="blob:"], [data-testid*="attachment"], button[aria-label*="Remove"], button[aria-label*="Удалить"]'));
  };

  async function typeAndSend(text, images) {
    const ed = getEditor();
    if (!ed) throw new Error("ChatGPT input box not found");
    const relock = _locked;
    if (relock) { if (isTextarea(ed)) ed.removeAttribute("readonly"); else ed.setAttribute("contenteditable", "true"); }
    try {
      // submitAndGetBase retries this function: never retype/re-attach needlessly.
      if (norm(editorText()) !== norm(text)) setEditorText(ed, text);
      const withImg = !!(images && images.length);
      if (withImg && !hasPendingAttachment()) {
        try { diag("attach.beforeCall", { count: images.length }); await attachImages(images); } catch (e) { diag("attach.threw", { msg: String((e && e.message) || e) }); }
      }
      // The send button appears once the editor has text, and (with an image)
      // only after the upload has finished.
      await waitFor(() => { const b = sendButton(); return !!b && !b.disabled; }, withImg ? 40000 : 5000);
      const btn = sendButton();
      diag("send.click", { found: !!btn, pending: hasPendingAttachment() });
      if (btn && !btn.disabled) { btn.click(); return; }
      const o = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
      ed.dispatchEvent(new KeyboardEvent("keydown", o));
      ed.dispatchEvent(new KeyboardEvent("keyup", o));
    } finally {
      if (relock) { const e2 = getEditor(); if (e2) { if (isTextarea(e2)) e2.setAttribute("readonly", ""); else e2.setAttribute("contenteditable", "false"); } }
    }
  }

  function stopGeneration() {
    const b = stopButton();
    if (b) try { b.click(); } catch {}
  }

  function enforceComposer() { return { ready: !!getEditor() }; }
  async function ensureComposerReady(reason) {
    diag("mode_ready", { reason, provider: "chatgpt" });
    return { ready: !!getEditor() };
  }

  // ── Errors / limits ─────────────────────────────────────────────────────
  function scanError() {
    try {
      for (const el of document.querySelectorAll(S.errorSurfaces)) {
        if (el.offsetParent === null) continue;
        if (el.closest(S.anyItem) || el.closest("#zs-root")) continue;
        const t = (el.innerText || "").trim();
        if (t.length > 8 && t.length < 600 && RE.contextLimit.test(t)) return t.slice(0, 240);
      }
    } catch {}
    if (!getEditor()) return "The input box disappeared (session ended?).";
    return null;
  }
  const isTooLongMsg = (text) => RE.tooLong.test(text);
  const isBusyMsg = (text) => RE.busy.test(text);

  // ── Images (paste onto the composer) ────────────────────────────────────
  function fileFromImage(img, i) {
    const mime = img.mimeType || "image/jpeg";
    const bin = atob(img.data);
    const arr = new Uint8Array(bin.length);
    for (let j = 0; j < bin.length; j++) arr[j] = bin.charCodeAt(j);
    return new File([arr], `zeroscript_${Date.now()}_${i}.${mime.includes("png") ? "png" : "jpg"}`, { type: mime });
  }
  async function attachImages(images) {
    const ed = getEditor();
    if (!ed || !images || !images.length) return false;
    const dt = new DataTransfer();
    images.forEach((img, i) => { try { dt.items.add(fileFromImage(img, i)); } catch {} });
    if (!dt.items.length) return false;
    ed.focus();
    ed.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    const ok = await waitFor(hasPendingAttachment, 15000);
    diag("attach.previewOk", { ok });
    return ok;
  }
  function clearAttachments() {
    try {
      const f = composerFrame();
      if (f) f.querySelectorAll('button[aria-label*="Remove"], button[aria-label*="Удалить"]').forEach((b) => { try { b.click(); } catch {} });
    } catch {}
  }

  // /c/<id> (also /g/<gpt>/c/<id>, /project/.../c/<id>) = real conversation; else "" (transient).
  const conversationKey = () => (/\/c\/[\w-]+/.test(location.pathname) && !chatIsEmpty() ? location.pathname : "");

  // ── Send interception ───────────────────────────────────────────────────
  function installSendHooks(handlers) {
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      const ed = getEditor();
      if (!ed || !ed.contains(e.target)) return;
      if (editorText().trim() === "") return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);

    document.addEventListener("click", (e) => {
      if (!getEditor()) return;
      const t = e.target && e.target.closest;
      if (!t) return;
      if (e.target.closest(S.stopBtn)) { handlers.onNativeStop(); return; }
      const btn = e.target.closest(S.sendBtn);
      if (!btn || btn.disabled) return;
      if (handlers.isBlocked()) return;
      if (!handlers.isStarted()) {
        if (!chatIsEmpty()) return;
        handlers.onBlockedAttempt();
        return;
      }
      handlers.onUserMessage(assistantCount());
    }, true);
  }

  // ── Tool-block camouflage ───────────────────────────────────────────────
  // Hide code blocks (<pre> and their header wrapper) that carry a command. React
  // re-renders them, so the item is also tagged .zs-cmd-mask-pre and overlay.css
  // keeps recreated blocks hidden with no flash.
  const CMD_SHAPE = /"(?:command|tool)"\s*:\s*"|###\s*lua|###mcp_tool###/i;
  function findToolBlockSpot(item /*, chip */) {
    if (!item) return null;
    const body = bodyOf(item);
    let hidAny = null;
    body.querySelectorAll("pre").forEach((pre) => {
      if (pre.closest(".zs-chip")) return;
      if (!CMD_SHAPE.test(pre.textContent || "")) return;
      const wrap = pre.closest(S.codeWrap) || pre;
      wrap.classList.add("zs-tool-hide");
      item.classList.add("zs-cmd-mask-pre");
      hidAny = hidAny || { parent: wrap.parentElement, ref: wrap };
    });
    [...body.children].forEach((el) => {
      if (el.classList.contains("zs-chip") || el.querySelector("pre")) return;
      const t = el.textContent || "";
      if (t.length < 600 && CMD_SHAPE.test(t)) {
        el.classList.add("zs-tool-hide");
        hidAny = hidAny || { parent: el.parentElement, ref: el };
      }
    });
    return hidAny;
  }

  return {
    id: "chatgpt",
    displayName: "ChatGPT",
    supportsVision: true, // ChatGPT models read images; verify with two captures in a row
    timings,
    chipAtItemLevel: true,
    reliableCounts: false,
    init({ diag: d } = {}) { if (d) diag = d; },
    allItems, isUserItem, isAssistantItem, itemText, classifyText,
    assistantCount, userCount, lastAssistant, lastAssistantId, readAssistant,
    streamLen, snapshot,
    getEditor, editorText, chatIsEmpty, isFreshChat, composerFrame, barAnchor,
    setInputLock, typeAndSend, stopGeneration,
    isGenerating, isBusyNow, isHardGenerating,
    enforceComposer, ensureComposerReady,
    turnHalted, findContinueBtn, clickContinueBtn,
    scanError, isTooLongMsg, isBusyMsg,
    attachImages, clearAttachments, conversationKey,
    installSendHooks, findToolBlockSpot,
  };
})();
